# Personal-Finance-Daily-Expense-Tracker

## R3 - Data Privacy & Security

* **Balance masking** - eye button in the navbar / Accounts page hides every balance. *Profile -> Mask Balances on Startup* saves the default.
* **PIN lock** - *Profile -> PIN Lock*: create / change / remove a 4-digit PIN (bcrypt hash) and choose which sections it locks. A locked section shows a PIN screen and stays open for 10 minutes. 5 wrong PINs = 5 minute lock-out.
* Locks are enforced **on the server** too (`middleware/pinMiddleware.js`): API calls to a locked section need the `x-pin-token` header returned by `POST /api/users/verify-pin`.

| Method | Endpoint | Purpose |
|---|---|---|
| PUT | `/api/users/privacy` | `{ maskBalances?, lockedSections?, pin? }` |
| POST | `/api/users/pin` | `{ pin, currentPin? }` create / change PIN |
| DELETE | `/api/users/pin` | `{ pin }` remove PIN |
| POST | `/api/users/verify-pin` | `{ pin }` -> `unlockToken` |

Tests: `cd backend && npm test` (needs local MongoDB) and `cd frontend && npm test`.
To lock another page: wrap it with `<PinLock section="budgets">` in `App.jsx` and add `router.use(requirePinUnlock('budgets'))` in its routes file.


## R19 - Automated Reminders

* **Settings** (Reminders page): in-app/browser notifications, e-mail reminders, daily "log your expenses" reminder at a chosen time, bill-due reminders (N days before + on the due day). Times use the user's own time zone.
* **Bills**: add bills (one-time or monthly) with a due date. Monthly bills roll forward automatically; "mark paid" moves them to next month.
* **How it works**: `services/cronService.js` runs `runReminderCycle()` every minute (node-cron). A unique `(user, dedupeKey)` index guarantees a reminder is never sent twice. E-mail goes through Nodemailer (`services/emailService.js`); without `SMTP_*` in `.env` mails are only printed in the server console.
* The bell in the navbar shows unread reminders and pops a browser notification for new ones (while the app is open).

| Method | Endpoint | Purpose |
|---|---|---|
| GET / PUT | `/api/reminders/settings` | notification settings |
| POST | `/api/reminders/test` | send a test reminder now |
| GET / POST | `/api/reminders` | list / add bills |
| PUT / DELETE | `/api/reminders/:id` | edit / delete a bill |
| POST | `/api/reminders/:id/paid` | mark a bill paid |
| GET | `/api/notifications` | bell list + unread count |
| PUT | `/api/notifications/:id/read`, `/read-all` | mark read |

## R20 - Audit Log / Activity History

* Every create / update / delete of accounts and bills, profile & security changes (PIN, privacy) and logins are recorded in `AuditLog`. Only field **names** are stored, never values (no balances, passwords or PINs).
* **Activity** page: search, filter by action / type / date range, pagination. The log is append-only (the model refuses updates and deletes, and there are no edit/delete endpoints).
* `GET /api/audit?action=&entityType=&from=&to=&search=&page=&limit=` - users only see their own history.
* To log a new module (e.g. transactions): `router.post('/', audit('CREATE', 'Transaction'), createTransaction)` using `audit` from `middleware/auditMiddleware.js` (add the name to `config/auditConstants.js` if it is new). For custom events call `logActivity(req, {...})`.
