const User = require('../models/User');
const Reminder = require('../models/Reminder');
const Notification = require('../models/Notification');
const { sendEmail } = require('./emailService');

const BILL_REMINDER_HOUR = 9; // bill reminders go out from 09:00 (user's local time)
const DAILY_WINDOW_MINUTES = 5; // daily reminder may fire up to 5 min late (e.g. after a restart)

// ---------------------------------------------------------------------------
// date helpers - all calendar dates are plain "YYYY-MM-DD" strings
// ---------------------------------------------------------------------------
const pad = (n) => String(n).padStart(2, '0');
const daysInMonth = (year, month) => new Date(Date.UTC(year, month, 0)).getUTCDate(); // month 1-12
const makeDate = (y, m, d) => `${y}-${pad(m)}-${pad(Math.min(d, daysInMonth(y, m)))}`;

const isRealDate = (str) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(str)) return false;
  const [y, m, d] = str.split('-').map(Number);
  return m >= 1 && m <= 12 && d >= 1 && d <= daysInMonth(y, m);
};

const daysBetween = (fromStr, toStr) =>
  Math.round((Date.parse(`${toStr}T00:00:00Z`) - Date.parse(`${fromStr}T00:00:00Z`)) / 86400000);

// the same day-of-month in the following month (clamped: 31st -> 28th/29th/30th)
const addMonth = (dateStr, dueDay) => {
  const [y, m] = dateStr.split('-').map(Number);
  return m === 12 ? makeDate(y + 1, 1, dueDay) : makeDate(y, m + 1, dueDay);
};

// first date >= today that falls on dueDay
const nextOccurrenceOnOrAfter = (dueDay, todayStr) => {
  const [y, m] = todayStr.split('-').map(Number);
  const candidate = makeDate(y, m, dueDay);
  return candidate >= todayStr ? candidate : addMonth(candidate, dueDay);
};

// "now" as the user sees it: { date: 'YYYY-MM-DD', minutes: minutes since midnight }
const getLocalParts = (now, timeZone) => {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(now);
  const get = (type) => parts.find((p) => p.type === type).value;
  return {
    date: `${get('year')}-${get('month')}-${get('day')}`,
    minutes: Number(get('hour')) * 60 + Number(get('minute')),
  };
};

const isValidTimeZone = (tz) => {
  try {
    new Intl.DateTimeFormat('en', { timeZone: tz });
    return typeof tz === 'string' && tz.length > 0;
  } catch (e) {
    return false;
  }
};

const toMinutes = (hhmm) => {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
};

// ---------------------------------------------------------------------------
// delivery
// ---------------------------------------------------------------------------
const emailHtml = (title, message) =>
  `<div style="font-family:Arial,sans-serif;max-width:480px;margin:auto;padding:24px;border:1px solid #e2e8f0;border-radius:12px">
     <h2 style="color:#059669;margin-top:0">${title}</h2>
     <p style="color:#334155;font-size:15px;line-height:1.5">${message}</p>
     <p style="color:#94a3b8;font-size:12px">Personal Finance &amp; Daily Expense Tracker - you can change reminders in your Reminders page.</p>
   </div>`;

// Creates the notification (and sends the e-mail) unless this exact reminder was already sent.
// Returns { status: 'sent' | 'duplicate' | 'skipped', notification }
const deliver = async (user, { type, title, message, dedupeKey, reminderId }, sendMail = sendEmail) => {
  const settings = user.reminderSettings || {};
  const wantsEmail = Boolean(settings.emailEnabled);
  const wantsInApp = settings.pushEnabled !== false;
  if (!wantsEmail && !wantsInApp) return { status: 'skipped' };

  let notification;
  try {
    notification = await Notification.create({
      user: user._id,
      type,
      title,
      message,
      inApp: wantsInApp,
      reminder: reminderId,
      dedupeKey,
    });
  } catch (error) {
    if (error.code === 11000) return { status: 'duplicate' }; // already sent earlier
    throw error;
  }

  if (wantsEmail) {
    try {
      await sendMail({ to: user.email, subject: title, text: message, html: emailHtml(title, message) });
      notification.emailStatus = 'sent';
    } catch (error) {
      console.error(`[reminders] e-mail to ${user.email} failed: ${error.message}`);
      notification.emailStatus = 'failed';
    }
    await notification.save();
  }
  return { status: 'sent', notification };
};

// ---------------------------------------------------------------------------
// the scheduler tick (called every minute by services/cronService.js)
// ---------------------------------------------------------------------------
const runReminderCycle = async ({ now = new Date(), sendMail = sendEmail } = {}) => {
  const summary = { daily: 0, bills: 0, rolled: 0 };

  const users = await User.find({
    $or: [{ 'reminderSettings.emailEnabled': true }, { 'reminderSettings.pushEnabled': { $ne: false } }],
  });

  for (const user of users) {
    try {
      const settings = user.publicReminders();
      const local = getLocalParts(now, isValidTimeZone(settings.timezone) ? settings.timezone : 'Asia/Dhaka');

      // 1) daily "log your expenses" reminder
      if (settings.dailyLogReminder) {
        const late = local.minutes - toMinutes(settings.dailyLogTime);
        if (late >= 0 && late < DAILY_WINDOW_MINUTES) {
          const result = await deliver(
            user,
            {
              type: 'daily_log',
              title: 'Time to log your expenses',
              message: "Don't forget to record today's income and expenses so your budget stays accurate.",
              dedupeKey: `daily:${local.date}`,
            },
            sendMail
          );
          if (result.status === 'sent') summary.daily += 1;
        }
      }

      // 2) bills: roll finished monthly bills forward, then notify
      const bills = await Reminder.find({ user: user._id, isActive: true });
      for (const bill of bills) {
        if (bill.repeat === 'monthly' && bill.dueDate < local.date) {
          bill.dueDate = nextOccurrenceOnOrAfter(bill.dueDay || Number(bill.dueDate.slice(8)), local.date);
          await bill.save();
          summary.rolled += 1;
        }

        if (!settings.billReminders || local.minutes < BILL_REMINDER_HOUR * 60) continue;

        const daysLeft = daysBetween(local.date, bill.dueDate);
        const isDueToday = daysLeft === 0;
        const isAdvanceDay = daysLeft > 0 && daysLeft === settings.billNotifyDaysBefore;
        if (!isDueToday && !isAdvanceDay) continue;

        const money = bill.amount > 0 ? ` (amount: ${bill.amount})` : '';
        const result = await deliver(
          user,
          {
            type: 'bill_due',
            title: isDueToday ? `Bill due today: ${bill.title}` : `Bill due in ${daysLeft} day(s): ${bill.title}`,
            message: isDueToday
              ? `"${bill.title}" is due today${money}.`
              : `"${bill.title}" is due on ${bill.dueDate}${money}.`,
            dedupeKey: `bill:${bill._id}:${bill.dueDate}:${daysLeft}`,
            reminderId: bill._id,
          },
          sendMail
        );
        if (result.status === 'sent') summary.bills += 1;
      }
    } catch (error) {
      // one user's problem must never stop reminders for everybody else
      console.error(`[reminders] failed for user ${user._id}: ${error.message}`);
    }
  }

  return summary;
};

module.exports = {
  runReminderCycle,
  deliver,
  isRealDate,
  isValidTimeZone,
  daysBetween,
  addMonth,
  makeDate,
  nextOccurrenceOnOrAfter,
  getLocalParts,
};
