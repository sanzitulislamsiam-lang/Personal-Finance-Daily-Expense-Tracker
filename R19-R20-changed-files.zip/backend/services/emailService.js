const nodemailer = require('nodemailer');

// R19: e-mail sending (Nodemailer).
// Set SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS in .env to send real e-mails
// (Gmail, SendGrid SMTP, Mailtrap ...). Without SMTP_HOST the mail is only printed
// to the console ("dev mode"), so the app works without any e-mail account.
let transporter = null;

const buildTransporter = () => {
  if (process.env.SMTP_HOST) {
    return nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true', // true for port 465
      auth: process.env.SMTP_USER
        ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        : undefined,
    });
  }
  return nodemailer.createTransport({ jsonTransport: true });
};

const getTransporter = () => {
  if (!transporter) transporter = buildTransporter();
  return transporter;
};

// used by tests to plug in a fake transporter (pass null to reset)
const setTransporter = (t) => {
  transporter = t;
};

const isRealEmailConfigured = () => Boolean(process.env.SMTP_HOST);

const sendEmail = async ({ to, subject, text, html }) => {
  const info = await getTransporter().sendMail({
    from: process.env.EMAIL_FROM || 'Finance Tracker <no-reply@finance-tracker.local>',
    to,
    subject,
    text,
    html,
  });
  if (!isRealEmailConfigured() && process.env.NODE_ENV !== 'test') {
    console.log(`[email:dev-mode] to=${to} | ${subject}\n${text}`);
  }
  return info;
};

module.exports = { sendEmail, setTransporter, isRealEmailConfigured };
