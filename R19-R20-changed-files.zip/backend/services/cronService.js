const cron = require('node-cron');
const { runReminderCycle } = require('./reminderService');

// R19: runs the reminder check once every minute.
// Started from server.js only (never from app.js), so tests do not start timers.
const startCronJobs = () => {
  cron.schedule('* * * * *', async () => {
    try {
      const summary = await runReminderCycle();
      if (summary.daily || summary.bills) {
        console.log(`[cron] reminders sent: ${summary.daily} daily, ${summary.bills} bill`);
      }
    } catch (error) {
      console.error('[cron] reminder cycle failed:', error.message);
    }
  });
  console.log('[cron] reminder scheduler started (every minute)');
};

module.exports = { startCronJobs };
