const AuditLog = require('../models/AuditLog');

// Names shown to the user in descriptions
const ENTITY_LABELS = { SplitBill: 'split bill', Reminder: 'bill reminder' };
const VERBS = { CREATE: 'Created', UPDATE: 'Updated', DELETE: 'Deleted', LOGIN: 'Logged in' };

// Core function: write one audit row.
// NEVER throws - a problem in the audit log must not break the user's real request.
// data: { action, entityType, entityId?, description?, changedFields?, transactionId?, user? }
const logActivity = async (req, data) => {
  try {
    const userId = data.user || (req.user && req.user._id);
    if (!userId) return null;
    return await AuditLog.create({
      user: userId,
      action: data.action,
      entityType: data.entityType,
      entityId: data.entityId ? String(data.entityId) : undefined,
      description: String(data.description || `${VERBS[data.action]} ${data.entityType}`).slice(0, 300),
      changedFields: data.changedFields || [],
      transactionId: data.transactionId,
      ipAddress: req.ip,
    });
  } catch (error) {
    console.error('[audit] could not write audit log:', error.message);
    return null;
  }
};

// Route-level helper, e.g.   router.post('/', audit('CREATE', 'Account'), createAccount)
// After the controller answers with a 2xx status it automatically logs the action.
// Entity id  = _id of the JSON response, or :id from the URL.
// Label      = res.locals.auditLabel (set by the controller) or name/title of the response.
const audit = (action, entityType) => (req, res, next) => {
  let responseBody;
  const originalJson = res.json.bind(res);
  res.json = (body) => {
    responseBody = body;
    return originalJson(body);
  };

  res.on('finish', () => {
    if (res.statusCode >= 400) return; // failed requests are not activity

    const body = responseBody && typeof responseBody === 'object' ? responseBody : {};
    const label = res.locals.auditLabel || body.name || body.title;
    const entityName = ENTITY_LABELS[entityType] || entityType.toLowerCase();

    logActivity(req, {
      action,
      entityType,
      entityId: body._id || body.id || req.params.id,
      description: `${VERBS[action]} ${entityName}${label ? ` "${label}"` : ''}`,
      changedFields: action === 'UPDATE' ? Object.keys(req.body || {}) : [],
    });
  });

  next();
};

module.exports = { logActivity, audit };
