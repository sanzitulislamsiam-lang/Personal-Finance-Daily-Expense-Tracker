/**
 * R20 - Audit Log / Activity History tests
 * Needs a local MongoDB (uses the separate finance_tracker_test database).
 */
process.env.JWT_SECRET = 'test_secret';
process.env.NODE_ENV = 'test';
const mongoose = require('mongoose');
const request = require('supertest');
const app = require('../app');
const AuditLog = require('../models/AuditLog');

const TEST_URI = process.env.TEST_MONGO_URI || 'mongodb://127.0.0.1:27017/finance_tracker_test';
const auth = (token) => ({ Authorization: `Bearer ${token}` });
let counter = 0;

const newUser = async () => {
  counter += 1;
  const email = `audit${counter}@test.com`;
  const res = await request(app)
    .post('/api/auth/register')
    .send({ name: `Audit User ${counter}`, email, password: 'secret123' });
  expect(res.status).toBe(201);
  return { token: res.body.token, id: res.body._id, email };
};

// audit rows are written right after the response is sent -> wait until `count` rows exist
const waitForLogs = async (userId, count = 1) => {
  for (let i = 0; i < 40; i++) {
    const n = await AuditLog.countDocuments({ user: userId });
    if (n >= count) return;
    await new Promise((r) => setTimeout(r, 25));
  }
  throw new Error(`expected ${count} audit rows`);
};

const getLogs = async (token, query = '') => {
  const res = await request(app).get(`/api/audit${query}`).set(auth(token));
  expect(res.status).toBe(200);
  return res.body;
};

beforeAll(async () => {
  await mongoose.connect(TEST_URI);
  await mongoose.connection.dropDatabase();
  await AuditLog.init();
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
});

describe('R20 - activity is recorded', () => {
  test('login is recorded', async () => {
    const u = await newUser();
    await request(app).post('/api/auth/login').send({ email: u.email, password: 'secret123' });
    await waitForLogs(u.id, 1);
    const { logs } = await getLogs(u.token);
    expect(logs[0]).toMatchObject({ action: 'LOGIN', entityType: 'Auth', description: 'Logged in' });
  });

  test('wrong password login is NOT recorded', async () => {
    const u = await newUser();
    await request(app).post('/api/auth/login').send({ email: u.email, password: 'wrong-pass' });
    await new Promise((r) => setTimeout(r, 150));
    expect(await AuditLog.countDocuments({ user: u.id })).toBe(0);
  });

  test('account create / update / delete are recorded with action, entity, id and name', async () => {
    const u = await newUser();
    const created = await request(app)
      .post('/api/accounts')
      .set(auth(u.token))
      .send({ name: 'Brac Bank', accountType: 'Bank', balance: 98765 });
    expect(created.status).toBe(201);
    const accId = created.body._id;

    const updated = await request(app)
      .put(`/api/accounts/${accId}`)
      .set(auth(u.token))
      .send({ name: 'Brac Bank Main', balance: 11111 });
    expect(updated.status).toBe(200);

    const deleted = await request(app).delete(`/api/accounts/${accId}`).set(auth(u.token));
    expect(deleted.status).toBe(200);

    await waitForLogs(u.id, 3);
    const { logs, total } = await getLogs(u.token);
    expect(total).toBe(3);

    // newest first: DELETE, UPDATE, CREATE
    expect(logs.map((l) => l.action)).toEqual(['DELETE', 'UPDATE', 'CREATE']);
    logs.forEach((l) => {
      expect(l.entityType).toBe('Account');
      expect(l.entityId).toBe(accId);
    });
    expect(logs[2].description).toBe('Created account "Brac Bank"');
    expect(logs[1].description).toBe('Updated account "Brac Bank Main"');
    expect(logs[1].changedFields).toEqual(['name', 'balance']);
    expect(logs[0].description).toBe('Deleted account "Brac Bank Main"');
  });

  test('values (balance amounts) are never stored in the log', async () => {
    const u = await newUser();
    await request(app)
      .post('/api/accounts')
      .set(auth(u.token))
      .send({ name: 'Secret', accountType: 'Cash', balance: 424242 });
    await waitForLogs(u.id, 1);
    const raw = JSON.stringify(await AuditLog.find({ user: u.id }).lean());
    expect(raw).not.toContain('424242');
  });

  test('failed requests (validation error / not found) are not recorded', async () => {
    const u = await newUser();
    const bad = await request(app).post('/api/accounts').set(auth(u.token)).send({ accountType: 'Cash' });
    expect(bad.status).toBe(400);
    const missing = await request(app)
      .delete('/api/accounts/64b7f0f0f0f0f0f0f0f0f0f0')
      .set(auth(u.token));
    expect(missing.status).toBe(404);
    await new Promise((r) => setTimeout(r, 150));
    expect(await AuditLog.countDocuments({ user: u.id })).toBe(0);
  });

  test('profile update logs field names only', async () => {
    const u = await newUser();
    await request(app)
      .put('/api/users/profile')
      .set(auth(u.token))
      .send({ name: 'Brand New Name', password: 'newsecret999' });
    await waitForLogs(u.id, 1);
    const { logs } = await getLogs(u.token);
    expect(logs[0]).toMatchObject({ action: 'UPDATE', entityType: 'Profile' });
    expect(logs[0].changedFields).toEqual(['name', 'password']);
    const raw = JSON.stringify(await AuditLog.find({ user: u.id }).lean());
    expect(raw).not.toContain('newsecret999');
    expect(raw).not.toContain('Brand New Name');
  });

  test('PIN create / change / remove are recorded without the digits', async () => {
    const u = await newUser();
    await request(app).post('/api/users/pin').set(auth(u.token)).send({ pin: '7391' });
    await request(app).post('/api/users/pin').set(auth(u.token)).send({ pin: '8246', currentPin: '7391' });
    await request(app).delete('/api/users/pin').set(auth(u.token)).send({ pin: '8246' });
    await waitForLogs(u.id, 3);

    const { logs } = await getLogs(u.token);
    expect(logs.map((l) => l.description)).toEqual([
      'Removed security PIN',
      'Changed security PIN',
      'Created security PIN',
    ]);
    logs.forEach((l) => expect(l.entityType).toBe('Security'));
    const raw = JSON.stringify(await AuditLog.find({ user: u.id }).lean());
    ['7391', '8246'].forEach((pin) => expect(raw).not.toContain(pin));
  });

  test('a failing audit write never breaks the real request', async () => {
    const u = await newUser();
    const spy = jest.spyOn(AuditLog, 'create').mockRejectedValue(new Error('db down'));
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const res = await request(app)
      .post('/api/accounts')
      .set(auth(u.token))
      .send({ name: 'Still works', accountType: 'Cash' });
    expect(res.status).toBe(201);
    await new Promise((r) => setTimeout(r, 100));
    spy.mockRestore();
    errSpy.mockRestore();
  });
});

describe('R20 - viewing the history', () => {
  let a;
  let b;

  beforeAll(async () => {
    a = await newUser();
    b = await newUser();
    // user A: 3 accounts created + 1 deleted + 1 profile update = 5 rows (+ nothing else)
    const ids = [];
    for (const name of ['Cash Wallet', 'bKash Personal', 'City Bank']) {
      const r = await request(app)
        .post('/api/accounts')
        .set(auth(a.token))
        .send({ name, accountType: 'Cash' });
      ids.push(r.body._id);
    }
    await request(app).delete(`/api/accounts/${ids[0]}`).set(auth(a.token));
    await request(app).put('/api/users/profile').set(auth(a.token)).send({ name: 'Alice' });
    await waitForLogs(a.id, 5);
    // user B: 1 row
    await request(app).post('/api/accounts').set(auth(b.token)).send({ name: 'B only', accountType: 'Cash' });
    await waitForLogs(b.id, 1);
  });

  test('requires login', async () => {
    const res = await request(app).get('/api/audit');
    expect(res.status).toBe(401);
  });

  test('users only see their own history', async () => {
    const bLogs = await getLogs(b.token);
    expect(bLogs.total).toBe(1);
    expect(bLogs.logs[0].description).toContain('B only');
    const aLogs = await getLogs(a.token);
    expect(aLogs.total).toBe(5);
    expect(JSON.stringify(aLogs)).not.toContain('B only');
  });

  test('pagination', async () => {
    const p1 = await getLogs(a.token, '?limit=2&page=1');
    expect(p1).toMatchObject({ page: 1, limit: 2, total: 5, pages: 3 });
    expect(p1.logs).toHaveLength(2);
    const p3 = await getLogs(a.token, '?limit=2&page=3');
    expect(p3.logs).toHaveLength(1);
    const ids = new Set([...p1.logs, ...(await getLogs(a.token, '?limit=2&page=2')).logs, ...p3.logs].map((l) => l._id));
    expect(ids.size).toBe(5); // no row repeated or skipped
  });

  test('filter by action', async () => {
    const r = await getLogs(a.token, '?action=DELETE');
    expect(r.total).toBe(1);
    expect(r.logs[0].action).toBe('DELETE');
  });

  test('filter by entityType', async () => {
    const acc = await getLogs(a.token, '?entityType=Account');
    expect(acc.total).toBe(4);
    const prof = await getLogs(a.token, '?entityType=Profile');
    expect(prof.total).toBe(1);
  });

  test('search in the description (case-insensitive, special characters are safe)', async () => {
    const r = await getLogs(a.token, '?search=bkash');
    expect(r.total).toBe(1);
    expect(r.logs[0].description).toContain('bKash Personal');
    const weird = await getLogs(a.token, `?search=${encodeURIComponent('.*(')}`);
    expect(weird.total).toBe(0);
  });

  test('filter by date range (whole "to" day is included)', async () => {
    const today = new Date().toISOString().slice(0, 10);
    const inRange = await getLogs(a.token, `?from=${today}&to=${today}`);
    expect(inRange.total).toBe(5);
    const past = await getLogs(a.token, '?from=2020-01-01&to=2020-01-31');
    expect(past.total).toBe(0);
  });

  test.each([
    '?action=EXPLODE',
    '?entityType=Nonsense',
    '?from=yesterday',
    '?to=2026-13-45',
  ])('invalid filter %s is a 400', async (q) => {
    const res = await request(app).get(`/api/audit${q}`).set(auth(a.token));
    expect(res.status).toBe(400);
  });

  test('limit is capped at 100 and bad paging values fall back to defaults', async () => {
    const r = await getLogs(a.token, '?limit=100000&page=-4');
    expect(r.limit).toBe(100);
    expect(r.page).toBe(1);
  });
});

describe('R20 - the history cannot be tampered with', () => {
  test('no edit / delete endpoints exist', async () => {
    const u = await newUser();
    const post = await request(app).post('/api/audit').set(auth(u.token)).send({ action: 'CREATE' });
    const del = await request(app).delete('/api/audit/123').set(auth(u.token));
    const put = await request(app).put('/api/audit/123').set(auth(u.token)).send({});
    [post, del, put].forEach((r) => expect(r.status).toBe(404));
  });

  test('the model itself refuses updates and deletes', async () => {
    const u = await newUser();
    const row = await AuditLog.create({
      user: u.id,
      action: 'CREATE',
      entityType: 'Account',
      description: 'Created account "X"',
    });
    await expect(AuditLog.updateOne({ _id: row._id }, { description: 'edited' })).rejects.toThrow(/read-only/);
    await expect(AuditLog.deleteOne({ _id: row._id })).rejects.toThrow(/read-only/);
    await expect(AuditLog.deleteMany({ user: u.id })).rejects.toThrow(/read-only/);
    await expect(AuditLog.findOneAndUpdate({ _id: row._id }, { action: 'DELETE' })).rejects.toThrow(/read-only/);
    const still = await AuditLog.findById(row._id);
    expect(still.description).toBe('Created account "X"');
  });
});
