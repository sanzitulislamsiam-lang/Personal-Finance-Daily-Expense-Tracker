/**
 * R19 - Automated Reminders tests
 *  - notification settings API
 *  - bill reminders CRUD
 *  - the scheduler cycle (daily "log your expenses" + bill due) with a fake clock and fake mailer
 *  - in-app notifications API
 * Needs a local MongoDB (uses the separate finance_tracker_test database).
 */
process.env.JWT_SECRET = 'test_secret';
process.env.NODE_ENV = 'test';
delete process.env.SMTP_HOST;
const mongoose = require('mongoose');
const request = require('supertest');
const app = require('../app');
const User = require('../models/User');
const Reminder = require('../models/Reminder');
const Notification = require('../models/Notification');
const AuditLog = require('../models/AuditLog');
const emailService = require('../services/emailService');
const { runReminderCycle, getLocalParts, addMonth, nextOccurrenceOnOrAfter, daysBetween } = require('../services/reminderService');

const TEST_URI = process.env.TEST_MONGO_URI || 'mongodb://127.0.0.1:27017/finance_tracker_test';
const auth = (token) => ({ Authorization: `Bearer ${token}` });
let counter = 0;

const newUser = async () => {
  counter += 1;
  const res = await request(app)
    .post('/api/auth/register')
    .send({ name: `Rem User ${counter}`, email: `rem${counter}@test.com`, password: 'secret123' });
  expect(res.status).toBe(201);
  return { token: res.body.token, id: res.body._id, email: res.body.email };
};

// a user created straight in the DB with the given reminder settings (for scheduler tests)
const dbUser = async (settings = {}) => {
  counter += 1;
  return User.create({
    name: `Cron User ${counter}`,
    email: `cron${counter}@test.com`,
    password: 'secret123',
    reminderSettings: settings,
  });
};

const bill = (user, fields = {}) =>
  Reminder.create({
    user: user._id,
    title: 'Internet',
    amount: 1200,
    dueDate: '2026-11-10',
    dueDay: 10,
    repeat: 'none',
    ...fields,
  });

const mailer = () => jest.fn().mockResolvedValue({ messageId: 'x' });
const notes = (user) => Notification.find({ user: user._id }).sort({ createdAt: 1 });
const addDays = (dateStr, n) => new Date(Date.parse(`${dateStr}T00:00:00Z`) + n * 86400000).toISOString().slice(0, 10);

// Dhaka is UTC+6 (no daylight saving)
const dhaka = (date, hhmm) => new Date(`${date}T${hhmm}:00+06:00`);

beforeAll(async () => {
  await mongoose.connect(TEST_URI);
  await mongoose.connection.dropDatabase();
  await Notification.init(); // builds the unique (user, dedupeKey) index
  await AuditLog.init();
});

afterEach(() => emailService.setTransporter(null));

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
});

describe('R19 - date helpers', () => {
  test('addMonth keeps the original day (31st -> 28th -> 31st) without drifting', () => {
    expect(addMonth('2026-01-31', 31)).toBe('2026-02-28');
    expect(addMonth('2026-02-28', 31)).toBe('2026-03-31');
    expect(addMonth('2028-01-31', 31)).toBe('2028-02-29'); // leap year
    expect(addMonth('2026-12-15', 15)).toBe('2027-01-15');
  });

  test('nextOccurrenceOnOrAfter', () => {
    expect(nextOccurrenceOnOrAfter(10, '2026-11-07')).toBe('2026-11-10');
    expect(nextOccurrenceOnOrAfter(5, '2026-11-07')).toBe('2026-12-05');
    expect(nextOccurrenceOnOrAfter(31, '2026-11-07')).toBe('2026-11-30');
    expect(nextOccurrenceOnOrAfter(7, '2026-11-07')).toBe('2026-11-07');
  });

  test('daysBetween and local time in a time zone', () => {
    expect(daysBetween('2026-11-07', '2026-11-10')).toBe(3);
    expect(daysBetween('2026-11-10', '2026-11-07')).toBe(-3);
    expect(getLocalParts(new Date('2026-11-07T14:00:00Z'), 'Asia/Dhaka')).toEqual({ date: '2026-11-07', minutes: 20 * 60 });
    expect(getLocalParts(new Date('2026-11-07T20:30:00Z'), 'Asia/Dhaka')).toEqual({ date: '2026-11-08', minutes: 150 });
  });
});

describe('R19 - notification settings API', () => {
  test('defaults', async () => {
    const u = await newUser();
    const res = await request(app).get('/api/reminders/settings').set(auth(u.token));
    expect(res.status).toBe(200);
    expect(res.body).toEqual({
      emailEnabled: false,
      pushEnabled: true,
      dailyLogReminder: false,
      dailyLogTime: '20:00',
      billReminders: true,
      billNotifyDaysBefore: 2,
      timezone: 'Asia/Dhaka',
    });
  });

  test('settings are saved and returned', async () => {
    const u = await newUser();
    const put = await request(app)
      .put('/api/reminders/settings')
      .set(auth(u.token))
      .send({ emailEnabled: true, dailyLogReminder: true, dailyLogTime: '07:45', billNotifyDaysBefore: 5, timezone: 'Europe/London' });
    expect(put.status).toBe(200);
    expect(put.body).toMatchObject({ emailEnabled: true, dailyLogReminder: true, dailyLogTime: '07:45', billNotifyDaysBefore: 5, timezone: 'Europe/London', pushEnabled: true });

    const get = await request(app).get('/api/reminders/settings').set(auth(u.token));
    expect(get.body.dailyLogTime).toBe('07:45');
    expect(get.body.timezone).toBe('Europe/London');
  });

  test.each([
    [{ dailyLogTime: '25:00' }],
    [{ dailyLogTime: '8:00' }],
    [{ dailyLogTime: 'noon' }],
    [{ billNotifyDaysBefore: -1 }],
    [{ billNotifyDaysBefore: 31 }],
    [{ billNotifyDaysBefore: 1.5 }],
    [{ billNotifyDaysBefore: '2' }],
    [{ timezone: 'Mars/Phobos' }],
    [{ emailEnabled: 'yes' }],
    [{ pushEnabled: 1 }],
    [{}],
  ])('invalid settings %j are rejected', async (body) => {
    const u = await newUser();
    const res = await request(app).put('/api/reminders/settings').set(auth(u.token)).send(body);
    expect(res.status).toBe(400);
  });

  test('requires login', async () => {
    expect((await request(app).get('/api/reminders/settings')).status).toBe(401);
    expect((await request(app).put('/api/reminders/settings').send({ emailEnabled: true })).status).toBe(401);
  });

  test('saving settings shows up in the activity history (R20)', async () => {
    const u = await newUser();
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ emailEnabled: true });
    let log;
    for (let i = 0; i < 40 && !log; i++) {
      log = await AuditLog.findOne({ user: u.id });
      if (!log) await new Promise((r) => setTimeout(r, 25));
    }
    expect(log).toMatchObject({ action: 'UPDATE', entityType: 'Reminder', description: 'Updated reminder settings' });
    expect(log.changedFields).toEqual(['emailEnabled']);
  });
});

describe('R19 - bill reminders API', () => {
  test('create, list (only mine, with daysLeft), update, mark paid, delete', async () => {
    const a = await newUser();
    const b = await newUser();
    const today = getLocalParts(new Date(), 'Asia/Dhaka').date;
    const due = addDays(today, 4);

    const created = await request(app)
      .post('/api/reminders')
      .set(auth(a.token))
      .send({ title: '  House rent ', amount: 15000, dueDate: due, repeat: 'monthly' });
    expect(created.status).toBe(201);
    expect(created.body).toMatchObject({ title: 'House rent', amount: 15000, dueDate: due, repeat: 'monthly', isActive: true });
    expect(created.body.dueDay).toBe(Number(due.slice(8)));
    const id = created.body._id;

    await request(app).post('/api/reminders').set(auth(b.token)).send({ title: 'B bill', dueDate: due });

    const list = await request(app).get('/api/reminders').set(auth(a.token));
    expect(list.status).toBe(200);
    expect(list.body).toHaveLength(1);
    expect(list.body[0].daysLeft).toBe(4);

    const upd = await request(app).put(`/api/reminders/${id}`).set(auth(a.token)).send({ amount: 16000, isActive: false });
    expect(upd.status).toBe(200);
    expect(upd.body).toMatchObject({ amount: 16000, isActive: false });

    const paid = await request(app).post(`/api/reminders/${id}/paid`).set(auth(a.token));
    expect(paid.status).toBe(200);
    expect(paid.body.dueDate).toBe(addMonth(due, Number(due.slice(8))));

    const del = await request(app).delete(`/api/reminders/${id}`).set(auth(a.token));
    expect(del.status).toBe(200);
    expect((await request(app).get('/api/reminders').set(auth(a.token))).body).toHaveLength(0);
  });

  test('mark paid on a one-time bill switches it off', async () => {
    const u = await newUser();
    const c = await request(app).post('/api/reminders').set(auth(u.token)).send({ title: 'Once', dueDate: '2030-01-15' });
    const paid = await request(app).post(`/api/reminders/${c.body._id}/paid`).set(auth(u.token));
    expect(paid.body).toMatchObject({ isActive: false, dueDate: '2030-01-15' });
  });

  test.each([
    [{ dueDate: '2026-12-01' }, 'missing title'],
    [{ title: '   ', dueDate: '2026-12-01' }, 'blank title'],
    [{ title: 'x'.repeat(101), dueDate: '2026-12-01' }, 'title too long'],
    [{ title: 'Rent' }, 'missing dueDate'],
    [{ title: 'Rent', dueDate: '2026-02-30' }, 'impossible date'],
    [{ title: 'Rent', dueDate: '01/12/2026' }, 'wrong date format'],
    [{ title: 'Rent', dueDate: '2026-12-01', amount: -5 }, 'negative amount'],
    [{ title: 'Rent', dueDate: '2026-12-01', amount: '100' }, 'amount as text'],
    [{ title: 'Rent', dueDate: '2026-12-01', repeat: 'weekly' }, 'unknown repeat'],
  ])('create rejects %j (%s)', async (body) => {
    const u = await newUser();
    const res = await request(app).post('/api/reminders').set(auth(u.token)).send(body);
    expect(res.status).toBe(400);
  });

  test("other users' bills and bad ids are 404", async () => {
    const a = await newUser();
    const b = await newUser();
    const c = await request(app).post('/api/reminders').set(auth(a.token)).send({ title: 'Mine', dueDate: '2030-01-15' });
    const id = c.body._id;
    expect((await request(app).put(`/api/reminders/${id}`).set(auth(b.token)).send({ amount: 1 })).status).toBe(404);
    expect((await request(app).delete(`/api/reminders/${id}`).set(auth(b.token))).status).toBe(404);
    expect((await request(app).post(`/api/reminders/${id}/paid`).set(auth(b.token))).status).toBe(404);
    expect((await request(app).delete('/api/reminders/not-an-id').set(auth(a.token))).status).toBe(404);
    expect(await Reminder.countDocuments({ _id: id })).toBe(1);
  });

  test('requires login', async () => {
    expect((await request(app).get('/api/reminders')).status).toBe(401);
    expect((await request(app).post('/api/reminders').send({ title: 'x', dueDate: '2030-01-01' })).status).toBe(401);
  });

  test('bill changes show up in the activity history (R20)', async () => {
    const u = await newUser();
    const c = await request(app).post('/api/reminders').set(auth(u.token)).send({ title: 'Netflix', dueDate: '2030-01-15' });
    await request(app).delete(`/api/reminders/${c.body._id}`).set(auth(u.token));
    let logs = [];
    for (let i = 0; i < 40 && logs.length < 2; i++) {
      logs = await AuditLog.find({ user: u.id }).sort({ timestamp: 1 });
      if (logs.length < 2) await new Promise((r) => setTimeout(r, 25));
    }
    expect(logs.map((l) => l.description)).toEqual(['Created bill reminder "Netflix"', 'Deleted bill reminder "Netflix"']);
  });
});

describe('R19 - scheduler: daily "log your expenses" reminder', () => {
  // the scheduler looks at ALL users, so every scheduler test starts from an empty database
  beforeEach(async () => {
    await Promise.all([User.deleteMany({}), Reminder.deleteMany({}), Notification.deleteMany({})]);
  });
  const settings = { emailEnabled: true, pushEnabled: true, dailyLogReminder: true, dailyLogTime: '20:00', timezone: 'Asia/Dhaka' };

  test('fires at the chosen local time, sends e-mail + in-app notification', async () => {
    const user = await dbUser(settings);
    const sendMail = mailer();
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    expect(r.daily).toBe(1);
    expect(sendMail).toHaveBeenCalledTimes(1);
    expect(sendMail.mock.calls[0][0]).toMatchObject({ to: user.email, subject: 'Time to log your expenses' });

    const [n] = await notes(user);
    expect(n).toMatchObject({ type: 'daily_log', inApp: true, isRead: false, emailStatus: 'sent' });
  });

  test('is not sent twice for the same day (dedupe), but is sent again the next day', async () => {
    const user = await dbUser(settings);
    const sendMail = mailer();
    await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    await runReminderCycle({ now: dhaka('2026-11-07', '20:03'), sendMail });
    expect(await Notification.countDocuments({ user: user._id })).toBe(1);
    expect(sendMail).toHaveBeenCalledTimes(1);

    await runReminderCycle({ now: dhaka('2026-11-08', '20:00'), sendMail });
    expect(await Notification.countDocuments({ user: user._id })).toBe(2);
  });

  test('only inside the time window (not before, not 5+ minutes late)', async () => {
    const user = await dbUser(settings);
    const sendMail = mailer();
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '19:59'), sendMail })).daily).toBe(0);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '20:05'), sendMail })).daily).toBe(0);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '23:00'), sendMail })).daily).toBe(0);
    expect(await Notification.countDocuments({ user: user._id })).toBe(0);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '20:04'), sendMail })).daily).toBe(1);
  });

  test("uses the user's own time zone", async () => {
    const user = await dbUser({ ...settings, dailyLogTime: '08:00', timezone: 'America/New_York' });
    const sendMail = mailer();
    // 12:00 UTC = 07:00 New York (EST) -> too early; 13:00 UTC = 08:00 New York -> fires
    expect((await runReminderCycle({ now: new Date('2026-11-07T12:00:00Z'), sendMail })).daily).toBe(0);
    expect((await runReminderCycle({ now: new Date('2026-11-07T13:00:00Z'), sendMail })).daily).toBe(1);
    expect(await Notification.countDocuments({ user: user._id })).toBe(1);
  });

  test('e-mail only: no bell notification, but the e-mail goes out', async () => {
    const user = await dbUser({ ...settings, pushEnabled: false });
    const sendMail = mailer();
    await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    expect(sendMail).toHaveBeenCalledTimes(1);
    const [n] = await notes(user);
    expect(n.inApp).toBe(false);
  });

  test('in-app only: no e-mail is sent', async () => {
    const user = await dbUser({ ...settings, emailEnabled: false });
    const sendMail = mailer();
    await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    expect(sendMail).not.toHaveBeenCalled();
    const [n] = await notes(user);
    expect(n).toMatchObject({ inApp: true, emailStatus: 'not_requested' });
  });

  test('both channels off, or daily reminder off: nothing happens', async () => {
    const off = await dbUser({ ...settings, emailEnabled: false, pushEnabled: false });
    const noDaily = await dbUser({ ...settings, dailyLogReminder: false });
    const sendMail = mailer();
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    expect(await Notification.countDocuments({ user: off._id })).toBe(0);
    expect(await Notification.countDocuments({ user: noDaily._id })).toBe(0);
    expect(r.daily).toBe(0);
  });

  test('a failing e-mail does not stop the cycle; it is marked as failed', async () => {
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const user = await dbUser(settings);
    const sendMail = jest.fn().mockRejectedValue(new Error('SMTP down'));
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '20:00'), sendMail });
    expect(r.daily).toBe(1);
    const [n] = await notes(user);
    expect(n).toMatchObject({ inApp: true, emailStatus: 'failed' });
    errSpy.mockRestore();
  });
});

describe('R19 - scheduler: bill due reminders', () => {
  // the scheduler looks at ALL users, so every scheduler test starts from an empty database
  beforeEach(async () => {
    await Promise.all([User.deleteMany({}), Reminder.deleteMany({}), Notification.deleteMany({})]);
  });
  const settings = { emailEnabled: true, pushEnabled: true, dailyLogReminder: false, billReminders: true, billNotifyDaysBefore: 3, timezone: 'Asia/Dhaka' };

  test('notifies N days before, from 09:00 local time, only once', async () => {
    const user = await dbUser(settings);
    await bill(user, { dueDate: '2026-11-10', amount: 1200 });
    const sendMail = mailer();

    expect((await runReminderCycle({ now: dhaka('2026-11-07', '08:59'), sendMail })).bills).toBe(0);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '09:00'), sendMail })).bills).toBe(1);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '09:01'), sendMail })).bills).toBe(0);
    expect((await runReminderCycle({ now: dhaka('2026-11-07', '18:00'), sendMail })).bills).toBe(0);

    const all = await notes(user);
    expect(all).toHaveLength(1);
    expect(all[0]).toMatchObject({ type: 'bill_due', title: 'Bill due in 3 day(s): Internet' });
    expect(all[0].message).toContain('2026-11-10');
    expect(all[0].message).toContain('1200');
    expect(sendMail).toHaveBeenCalledTimes(1);
  });

  test('also notifies on the due day, and stays quiet on the days in between', async () => {
    const user = await dbUser(settings);
    await bill(user, { dueDate: '2026-11-10' });
    const sendMail = mailer();
    const quiet = ['2026-11-08', '2026-11-09']; // 2 and 1 day(s) left
    for (const day of quiet) {
      expect((await runReminderCycle({ now: dhaka(day, '10:00'), sendMail })).bills).toBe(0);
    }
    expect((await runReminderCycle({ now: dhaka('2026-11-10', '10:00'), sendMail })).bills).toBe(1);
    const all = await notes(user);
    expect(all[0].title).toBe('Bill due today: Internet');
  });

  test('a late first run on the day still notifies (server was down at 09:00)', async () => {
    const user = await dbUser(settings);
    await bill(user, { dueDate: '2026-11-10' });
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '15:30'), sendMail: mailer() });
    expect(r.bills).toBe(1);
    expect(await Notification.countDocuments({ user: user._id })).toBe(1);
  });

  test('paused bills, billReminders off, and other users are ignored', async () => {
    const owner = await dbUser(settings);
    const other = await dbUser(settings);
    const off = await dbUser({ ...settings, billReminders: false });
    await bill(owner, { dueDate: '2026-11-10', isActive: false });
    await bill(off, { dueDate: '2026-11-10' });
    const sendMail = mailer();
    await runReminderCycle({ now: dhaka('2026-11-07', '10:00'), sendMail });
    expect(await Notification.countDocuments({ user: owner._id })).toBe(0);
    expect(await Notification.countDocuments({ user: off._id })).toBe(0);
    expect(await Notification.countDocuments({ user: other._id })).toBe(0);
  });

  test('a past monthly bill rolls forward to the next due date (even before 09:00)', async () => {
    const user = await dbUser(settings);
    const b = await bill(user, { dueDate: '2026-10-31', dueDay: 31, repeat: 'monthly' });
    const once = await bill(user, { title: 'Old one-time', dueDate: '2026-10-01', dueDay: 1, repeat: 'none' });
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '06:00'), sendMail: mailer() });
    expect(r.rolled).toBe(1);
    expect((await Reminder.findById(b._id)).dueDate).toBe('2026-11-30');
    expect((await Reminder.findById(once._id)).dueDate).toBe('2026-10-01'); // one-time bills stay as they are
  });

  test('each reminder is a separate notification (two bills, same day)', async () => {
    const user = await dbUser(settings);
    await bill(user, { title: 'Rent', dueDate: '2026-11-10' });
    await bill(user, { title: 'Netflix', dueDate: '2026-11-10' });
    const r = await runReminderCycle({ now: dhaka('2026-11-07', '09:30'), sendMail: mailer() });
    expect(r.bills).toBe(2);
    expect(await Notification.countDocuments({ user: user._id })).toBe(2);
  });
});

describe('R19 - in-app notifications API', () => {
  test('list, unread count, unreadOnly, mark read, mark all read', async () => {
    const u = await newUser();
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ pushEnabled: true });
    for (let i = 0; i < 3; i++) await request(app).post('/api/reminders/test').set(auth(u.token));

    const list = await request(app).get('/api/notifications').set(auth(u.token));
    expect(list.status).toBe(200);
    expect(list.body.notifications).toHaveLength(3);
    expect(list.body.unreadCount).toBe(3);

    const firstId = list.body.notifications[0]._id;
    expect((await request(app).put(`/api/notifications/${firstId}/read`).set(auth(u.token))).status).toBe(200);
    const after = await request(app).get('/api/notifications').set(auth(u.token));
    expect(after.body.unreadCount).toBe(2);
    const unreadOnly = await request(app).get('/api/notifications?unreadOnly=true').set(auth(u.token));
    expect(unreadOnly.body.notifications).toHaveLength(2);

    const all = await request(app).put('/api/notifications/read-all').set(auth(u.token));
    expect(all.status).toBe(200);
    expect((await request(app).get('/api/notifications').set(auth(u.token))).body.unreadCount).toBe(0);
  });

  test('limit is applied; newest first', async () => {
    const u = await newUser();
    for (let i = 0; i < 4; i++) await request(app).post('/api/reminders/test').set(auth(u.token));
    const res = await request(app).get('/api/notifications?limit=2').set(auth(u.token));
    expect(res.body.notifications).toHaveLength(2);
    const t = res.body.notifications.map((n) => new Date(n.createdAt).getTime());
    expect(t[0]).toBeGreaterThanOrEqual(t[1]);
  });

  test("users cannot see or touch each other's notifications", async () => {
    const a = await newUser();
    const b = await newUser();
    await request(app).post('/api/reminders/test').set(auth(a.token));
    const aList = await request(app).get('/api/notifications').set(auth(a.token));
    const id = aList.body.notifications[0]._id;

    expect((await request(app).get('/api/notifications').set(auth(b.token))).body.notifications).toHaveLength(0);
    expect((await request(app).put(`/api/notifications/${id}/read`).set(auth(b.token))).status).toBe(404);
    expect((await request(app).put('/api/notifications/garbage/read').set(auth(a.token))).status).toBe(404);
    await request(app).put('/api/notifications/read-all').set(auth(b.token));
    expect((await request(app).get('/api/notifications').set(auth(a.token))).body.unreadCount).toBe(1);
  });

  test('e-mail-only notifications are not shown in the bell', async () => {
    const u = await newUser();
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ pushEnabled: false, emailEnabled: true });
    emailService.setTransporter({ sendMail: jest.fn().mockResolvedValue({}) });
    const test = await request(app).post('/api/reminders/test').set(auth(u.token));
    expect(test.status).toBe(200);
    const list = await request(app).get('/api/notifications').set(auth(u.token));
    expect(list.body.notifications).toHaveLength(0);
    expect(list.body.unreadCount).toBe(0);
  });

  test('requires login', async () => {
    expect((await request(app).get('/api/notifications')).status).toBe(401);
    expect((await request(app).put('/api/notifications/read-all')).status).toBe(401);
  });
});

describe('R19 - "send test reminder" and the e-mail service', () => {
  test('test reminder reaches the e-mail transport with the right recipient', async () => {
    const u = await newUser();
    const sendMail = jest.fn().mockResolvedValue({ messageId: 'ok' });
    emailService.setTransporter({ sendMail });
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ emailEnabled: true });

    const res = await request(app).post('/api/reminders/test').set(auth(u.token));
    expect(res.status).toBe(200);
    expect(res.body).toMatchObject({ inApp: true, emailStatus: 'sent' });
    expect(sendMail).toHaveBeenCalledTimes(1);
    expect(sendMail.mock.calls[0][0]).toMatchObject({ to: u.email, subject: 'Test reminder' });
    expect(sendMail.mock.calls[0][0].from).toContain('no-reply');
  });

  test('a failing e-mail transport is reported as failed, not as a server error', async () => {
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const u = await newUser();
    emailService.setTransporter({ sendMail: jest.fn().mockRejectedValue(new Error('auth failed')) });
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ emailEnabled: true });
    const res = await request(app).post('/api/reminders/test').set(auth(u.token));
    expect(res.status).toBe(200);
    expect(res.body.emailStatus).toBe('failed');
    errSpy.mockRestore();
  });

  test('with both channels off the test is refused with a helpful message', async () => {
    const u = await newUser();
    await request(app).put('/api/reminders/settings').set(auth(u.token)).send({ pushEnabled: false, emailEnabled: false });
    const res = await request(app).post('/api/reminders/test').set(auth(u.token));
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/Turn on/);
  });

  test('without SMTP settings sendEmail works in dev mode (nothing leaves the machine)', async () => {
    const info = await emailService.sendEmail({ to: 'a@b.com', subject: 'Hello', text: 'Body' });
    const sent = JSON.parse(info.message);
    expect(sent.subject).toBe('Hello');
    expect(sent.to[0].address).toBe('a@b.com');
  });
});
