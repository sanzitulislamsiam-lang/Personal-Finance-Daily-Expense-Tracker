// R20: what can appear in the activity history
const AUDIT_ACTIONS = ['CREATE', 'UPDATE', 'DELETE', 'LOGIN'];

// Add a new name here when a new module (Transaction, Budget, ...) starts writing audit logs
const AUDIT_ENTITIES = [
  'Account',
  'Transaction',
  'Category',
  'Budget',
  'Goal',
  'Debt',
  'SplitBill',
  'Reminder',
  'Profile',
  'Security',
  'Auth',
];

module.exports = { AUDIT_ACTIONS, AUDIT_ENTITIES };
