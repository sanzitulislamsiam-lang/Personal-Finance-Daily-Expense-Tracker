const express = require('express');
const router = express.Router();
const {
  getAccounts,
  getAccountById,
  createAccount,
  updateAccount,
  deleteAccount,
} = require('../controllers/accountController');
const { protect } = require('../middleware/authMiddleware');
const { requirePinUnlock } = require('../middleware/pinMiddleware');
const { audit } = require('../middleware/auditMiddleware');

router.use(protect); // All account routes require authentication
router.use(requirePinUnlock('accounts')); // R3: PIN lock (only if the user locked "accounts")

// R20: create / update / delete are written to the activity history
router.route('/')
  .get(getAccounts)
  .post(audit('CREATE', 'Account'), createAccount);

router.route('/:id')
  .get(getAccountById)
  .put(audit('UPDATE', 'Account'), updateAccount)
  .delete(audit('DELETE', 'Account'), deleteAccount);

module.exports = router;
