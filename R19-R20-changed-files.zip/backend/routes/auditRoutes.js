const express = require('express');
const router = express.Router();
const { getAuditLogs } = require('../controllers/auditController');
const { protect } = require('../middleware/authMiddleware');

// R20: read-only. There is deliberately no POST / PUT / DELETE - the history cannot be edited.
router.get('/', protect, getAuditLogs);

module.exports = router;
