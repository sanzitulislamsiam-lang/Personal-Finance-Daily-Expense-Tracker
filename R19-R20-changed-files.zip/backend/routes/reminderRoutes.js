const express = require('express');
const router = express.Router();
const c = require('../controllers/reminderController');
const { protect } = require('../middleware/authMiddleware');
const { audit } = require('../middleware/auditMiddleware');

router.use(protect);

// R19: notification settings + test button (must come before "/:id")
router.route('/settings').get(c.getSettings).put(c.updateSettings);
router.post('/test', c.sendTest);

// R19: bill reminders (create / update / delete / mark paid are written to the activity history - R20)
router.route('/').get(c.listReminders).post(audit('CREATE', 'Reminder'), c.createReminder);
router.post('/:id/paid', audit('UPDATE', 'Reminder'), c.markPaid);
router.route('/:id').put(audit('UPDATE', 'Reminder'), c.updateReminder).delete(audit('DELETE', 'Reminder'), c.deleteReminder);

module.exports = router;
