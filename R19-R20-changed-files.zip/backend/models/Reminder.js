const mongoose = require('mongoose');

// R19: a bill the user wants to be reminded about (rent, Netflix, internet ...).
// dueDate is a plain calendar date "YYYY-MM-DD" (no time zone problems).
const reminderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 100 },
    amount: { type: Number, default: 0, min: 0 },
    dueDate: { type: String, required: true, match: /^\d{4}-\d{2}-\d{2}$/ },
    dueDay: { type: Number, min: 1, max: 31 }, // original day of month, so Jan 31 -> Feb 28 -> Mar 31 (no drift)
    repeat: { type: String, enum: ['none', 'monthly'], default: 'none' },
    notes: { type: String, trim: true, maxlength: 300 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Reminder', reminderSchema);
