const mongoose = require('mongoose');
const { AUDIT_ACTIONS, AUDIT_ENTITIES } = require('../config/auditConstants');

// R20: one row = one thing a user did (created / updated / deleted / logged in).
// Only field NAMES are stored in changedFields - never values (so no passwords, PINs or balances leak).
const auditLogSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    action: { type: String, enum: AUDIT_ACTIONS, required: true },
    entityType: { type: String, enum: AUDIT_ENTITIES, required: true },
    entityId: { type: String },
    description: { type: String, required: true, maxlength: 300 },
    changedFields: { type: [String], default: [] },
    transactionId: { type: mongoose.Schema.Types.ObjectId }, // set when the entry belongs to a transaction
    ipAddress: { type: String },
    timestamp: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

// fast "my latest activity" queries
auditLogSchema.index({ user: 1, timestamp: -1 });

// Integrity: an audit log is append-only. Updating or deleting rows is refused.
const blocked = function () {
  throw new Error('Audit logs are read-only and cannot be modified or deleted');
};
[
  'updateOne',
  'updateMany',
  'findOneAndUpdate',
  'findOneAndReplace',
  'replaceOne',
  'deleteOne',
  'deleteMany',
  'findOneAndDelete',
].forEach((op) => auditLogSchema.pre(op, blocked));

module.exports = mongoose.model('AuditLog', auditLogSchema);
