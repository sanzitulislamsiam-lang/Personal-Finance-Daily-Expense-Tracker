const mongoose = require('mongoose');

// R19: one notification = one reminder that was triggered for a user.
// The unique (user, dedupeKey) index guarantees the same reminder is never sent twice,
// even if the scheduler runs again or the server restarts.
const notificationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: { type: String, enum: ['daily_log', 'bill_due', 'test'], required: true },
    title: { type: String, required: true },
    message: { type: String, required: true },
    inApp: { type: Boolean, default: true }, // shown in the bell / browser notification?
    isRead: { type: Boolean, default: false },
    emailStatus: { type: String, enum: ['not_requested', 'sent', 'failed'], default: 'not_requested' },
    reminder: { type: mongoose.Schema.Types.ObjectId, ref: 'Reminder' },
    dedupeKey: { type: String, required: true },
  },
  { timestamps: true }
);

notificationSchema.index({ user: 1, dedupeKey: 1 }, { unique: true });
notificationSchema.index({ user: 1, createdAt: -1 });

module.exports = mongoose.model('Notification', notificationSchema);
