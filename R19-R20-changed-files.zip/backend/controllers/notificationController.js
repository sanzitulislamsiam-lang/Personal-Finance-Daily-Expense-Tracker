const mongoose = require('mongoose');
const Notification = require('../models/Notification');

// @desc    My in-app notifications (newest first) + how many are unread
// @route   GET /api/notifications?unreadOnly=true&limit=20
const getNotifications = async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 50);
    const base = { user: req.user._id, inApp: true };
    const query = req.query.unreadOnly === 'true' ? { ...base, isRead: false } : base;

    const [notifications, unreadCount] = await Promise.all([
      Notification.find(query).sort({ createdAt: -1, _id: -1 }).limit(limit),
      Notification.countDocuments({ ...base, isRead: false }),
    ]);
    res.json({ notifications, unreadCount });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route PUT /api/notifications/:id/read
const markRead = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'Notification not found' });
    }
    const result = await Notification.updateOne(
      { _id: req.params.id, user: req.user._id },
      { $set: { isRead: true } }
    );
    if (result.matchedCount === 0) return res.status(404).json({ message: 'Notification not found' });
    res.json({ message: 'Marked as read' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route PUT /api/notifications/read-all
const markAllRead = async (req, res) => {
  try {
    const result = await Notification.updateMany(
      { user: req.user._id, inApp: true, isRead: false },
      { $set: { isRead: true } }
    );
    res.json({ message: 'All marked as read', updated: result.modifiedCount });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getNotifications, markRead, markAllRead };
