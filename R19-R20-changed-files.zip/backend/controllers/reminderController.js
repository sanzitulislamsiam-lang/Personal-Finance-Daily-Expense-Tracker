const mongoose = require('mongoose');
const User = require('../models/User');
const Reminder = require('../models/Reminder');
const { logActivity } = require('../middleware/auditMiddleware');
const {
  deliver,
  isRealDate,
  isValidTimeZone,
  daysBetween,
  addMonth,
  getLocalParts,
} = require('../services/reminderService');

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const isBool = (v) => typeof v === 'boolean';

// ---------------------------------------------------------------------------
// notification settings
// ---------------------------------------------------------------------------

// @route GET /api/reminders/settings
const getSettings = async (req, res) => {
  res.json(req.user.publicReminders());
};

// @route PUT /api/reminders/settings
const updateSettings = async (req, res) => {
  try {
    const b = req.body;
    const $set = {};

    for (const key of ['emailEnabled', 'pushEnabled', 'dailyLogReminder', 'billReminders']) {
      if (b[key] !== undefined) {
        if (!isBool(b[key])) return res.status(400).json({ message: `${key} must be true or false` });
        $set[`reminderSettings.${key}`] = b[key];
      }
    }
    if (b.dailyLogTime !== undefined) {
      if (typeof b.dailyLogTime !== 'string' || !TIME_RE.test(b.dailyLogTime)) {
        return res.status(400).json({ message: 'dailyLogTime must look like 20:00 (24-hour HH:MM)' });
      }
      $set['reminderSettings.dailyLogTime'] = b.dailyLogTime;
    }
    if (b.billNotifyDaysBefore !== undefined) {
      const n = b.billNotifyDaysBefore;
      if (!Number.isInteger(n) || n < 0 || n > 30) {
        return res.status(400).json({ message: 'billNotifyDaysBefore must be a whole number from 0 to 30' });
      }
      $set['reminderSettings.billNotifyDaysBefore'] = n;
    }
    if (b.timezone !== undefined) {
      if (!isValidTimeZone(b.timezone)) {
        return res.status(400).json({ message: 'timezone is not valid (example: Asia/Dhaka)' });
      }
      $set['reminderSettings.timezone'] = b.timezone;
    }
    if (Object.keys($set).length === 0) {
      return res.status(400).json({ message: 'Nothing to update' });
    }

    await User.updateOne({ _id: req.user._id }, { $set });
    const updated = await User.findById(req.user._id);

    await logActivity(req, {
      action: 'UPDATE',
      entityType: 'Reminder',
      entityId: req.user._id,
      description: 'Updated reminder settings',
      changedFields: Object.keys($set).map((k) => k.replace('reminderSettings.', '')),
    });

    res.json({ ...updated.publicReminders(), message: 'Reminder settings saved' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route POST /api/reminders/test  - sends a test notification right now (to check the setup)
const sendTest = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const key = `test:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    const { status, notification } = await deliver(user, {
      type: 'test',
      title: 'Test reminder',
      message: 'This is a test reminder from your Finance Tracker. Everything is working!',
      dedupeKey: key,
    });

    if (status === 'skipped') {
      return res
        .status(400)
        .json({ message: 'Turn on e-mail or in-app notifications first, then send a test.' });
    }
    res.json({
      message: 'Test reminder sent',
      inApp: notification.inApp,
      emailStatus: notification.emailStatus,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ---------------------------------------------------------------------------
// bills
// ---------------------------------------------------------------------------
const findOwnBill = async (req) => {
  if (!mongoose.isValidObjectId(req.params.id)) return null;
  return Reminder.findOne({ _id: req.params.id, user: req.user._id });
};

// returns an error message, or null when the fields are fine. Only checks fields that are present.
const validateBill = (b, { creating }) => {
  if (creating || b.title !== undefined) {
    if (typeof b.title !== 'string' || !b.title.trim()) return 'Title is required';
    if (b.title.trim().length > 100) return 'Title must be 100 characters or less';
  }
  if (creating || b.dueDate !== undefined) {
    if (typeof b.dueDate !== 'string' || !isRealDate(b.dueDate)) return 'dueDate must be a real date like 2026-12-01';
  }
  if (b.amount !== undefined && (typeof b.amount !== 'number' || !Number.isFinite(b.amount) || b.amount < 0)) {
    return 'amount must be a number that is 0 or more';
  }
  if (b.repeat !== undefined && !['none', 'monthly'].includes(b.repeat)) return 'repeat must be none or monthly';
  if (b.isActive !== undefined && !isBool(b.isActive)) return 'isActive must be true or false';
  if (b.notes !== undefined && (typeof b.notes !== 'string' || b.notes.length > 300)) {
    return 'notes must be text of 300 characters or less';
  }
  return null;
};

// @route GET /api/reminders
const listReminders = async (req, res) => {
  try {
    const bills = await Reminder.find({ user: req.user._id }).sort({ dueDate: 1 });
    const today = getLocalParts(new Date(), req.user.publicReminders().timezone).date;
    res.json(bills.map((b) => ({ ...b.toObject(), daysLeft: daysBetween(today, b.dueDate) })));
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route POST /api/reminders
const createReminder = async (req, res) => {
  try {
    const problem = validateBill(req.body, { creating: true });
    if (problem) return res.status(400).json({ message: problem });

    const { title, amount, dueDate, repeat, notes } = req.body;
    const bill = await Reminder.create({
      user: req.user._id,
      title: title.trim(),
      amount: amount || 0,
      dueDate,
      dueDay: Number(dueDate.slice(8)),
      repeat: repeat || 'none',
      notes,
    });
    res.status(201).json(bill);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route PUT /api/reminders/:id
const updateReminder = async (req, res) => {
  try {
    const bill = await findOwnBill(req);
    if (!bill) return res.status(404).json({ message: 'Reminder not found' });

    const problem = validateBill(req.body, { creating: false });
    if (problem) return res.status(400).json({ message: problem });

    const b = req.body;
    if (b.title !== undefined) bill.title = b.title.trim();
    if (b.amount !== undefined) bill.amount = b.amount;
    if (b.repeat !== undefined) bill.repeat = b.repeat;
    if (b.notes !== undefined) bill.notes = b.notes;
    if (b.isActive !== undefined) bill.isActive = b.isActive;
    if (b.dueDate !== undefined) {
      bill.dueDate = b.dueDate;
      bill.dueDay = Number(b.dueDate.slice(8));
    }
    res.json(await bill.save());
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route DELETE /api/reminders/:id
const deleteReminder = async (req, res) => {
  try {
    const bill = await findOwnBill(req);
    if (!bill) return res.status(404).json({ message: 'Reminder not found' });
    await Reminder.deleteOne({ _id: bill._id });
    res.locals.auditLabel = bill.title;
    res.json({ message: 'Reminder deleted', id: String(bill._id) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @route POST /api/reminders/:id/paid
// monthly bill -> moves to next month; one-time bill -> switched off
const markPaid = async (req, res) => {
  try {
    const bill = await findOwnBill(req);
    if (!bill) return res.status(404).json({ message: 'Reminder not found' });

    if (bill.repeat === 'monthly') {
      bill.dueDate = addMonth(bill.dueDate, bill.dueDay || Number(bill.dueDate.slice(8)));
    } else {
      bill.isActive = false;
    }
    res.json(await bill.save());
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  getSettings,
  updateSettings,
  sendTest,
  listReminders,
  createReminder,
  updateReminder,
  deleteReminder,
  markPaid,
};
