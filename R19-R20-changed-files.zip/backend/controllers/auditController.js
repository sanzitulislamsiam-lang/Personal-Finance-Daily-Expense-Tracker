const AuditLog = require('../models/AuditLog');
const { AUDIT_ACTIONS, AUDIT_ENTITIES } = require('../config/auditConstants');

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// "2026-11-07" -> Date, or null when it is not a real date
const parseDay = (value) => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const d = new Date(`${value}T00:00:00.000Z`);
  return Number.isNaN(d.getTime()) ? null : d;
};

// @desc    Activity history of the logged-in user (newest first), with filters + pagination (R20)
// @route   GET /api/audit?action=&entityType=&from=&to=&search=&page=&limit=
// @access  Private
const getAuditLogs = async (req, res) => {
  try {
    const { action, entityType, from, to, search } = req.query;
    const query = { user: req.user._id }; // users can only ever see their own history

    if (action) {
      if (!AUDIT_ACTIONS.includes(action)) {
        return res.status(400).json({ message: `action must be one of: ${AUDIT_ACTIONS.join(', ')}` });
      }
      query.action = action;
    }

    if (entityType) {
      if (!AUDIT_ENTITIES.includes(entityType)) {
        return res.status(400).json({ message: `entityType must be one of: ${AUDIT_ENTITIES.join(', ')}` });
      }
      query.entityType = entityType;
    }

    if (from || to) {
      query.timestamp = {};
      if (from) {
        const d = parseDay(from);
        if (!d) return res.status(400).json({ message: 'from must be a date like 2026-11-01' });
        query.timestamp.$gte = d;
      }
      if (to) {
        const d = parseDay(to);
        if (!d) return res.status(400).json({ message: 'to must be a date like 2026-11-30' });
        query.timestamp.$lt = new Date(d.getTime() + 24 * 60 * 60 * 1000); // whole "to" day included
      }
    }

    if (search && String(search).trim()) {
      query.description = { $regex: escapeRegex(String(search).trim().slice(0, 100)), $options: 'i' };
    }

    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);

    const [total, logs] = await Promise.all([
      AuditLog.countDocuments(query),
      AuditLog.find(query)
        .sort({ timestamp: -1, _id: -1 })
        .skip((page - 1) * limit)
        .limit(limit),
    ]);

    res.json({ logs, page, limit, total, pages: Math.max(Math.ceil(total / limit), 1) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = { getAuditLogs };
