import React, { useState, useEffect, useCallback } from 'react';
import { BellRing, Mail, Smartphone, CalendarClock, PencilLine, Send, Loader2, CheckCircle2, AlertCircle, Trash2, Check, Pause, Play, Plus } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  getReminderSettings,
  updateReminderSettings,
  sendTestReminder,
  getBills,
  createBill,
  updateBill,
  deleteBill,
  markBillPaid,
} from '../api/reminderApi';

const cardCls =
  'bg-white dark:bg-[#121826] p-6 sm:p-8 rounded-3xl border border-slate-200/70 dark:border-slate-800/80 shadow-sm space-y-5';
const inputCls =
  'w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/40';
const primaryBtn =
  'inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold rounded-xl text-xs tracking-wider uppercase disabled:opacity-40 transition-all';
const ghostBtn =
  'inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 transition-all';

const Toggle = ({ checked, onChange, label }) => (
  <button
    type="button"
    role="switch"
    aria-checked={checked}
    aria-label={label}
    onClick={() => onChange(!checked)}
    className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${checked ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'}`}
  >
    <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${checked ? 'translate-x-5' : ''}`} />
  </button>
);

const Row = ({ icon: Icon, title, hint, children }) => (
  <div className="flex items-start justify-between gap-4 py-3 border-b border-slate-100 dark:border-slate-800 last:border-0">
    <div className="flex gap-3">
      <Icon className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
      <div>
        <p className="text-sm font-bold text-slate-900 dark:text-white">{title}</p>
        <p className="text-xs text-slate-500 dark:text-slate-400">{hint}</p>
      </div>
    </div>
    {children}
  </div>
);

const dueLabel = (daysLeft) => {
  if (daysLeft < 0) return { text: `Overdue by ${-daysLeft} day(s)`, cls: 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-800/60' };
  if (daysLeft === 0) return { text: 'Due today', cls: 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-800/60' };
  return { text: `Due in ${daysLeft} day(s)`, cls: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700' };
};

const blankBill = { title: '', amount: '', dueDate: '', repeat: 'none' };

// R19: reminder settings + bill reminders
export default function Reminders() {
  const { user } = useAuth();
  const [settings, setSettings] = useState(null);
  const [bills, setBills] = useState([]);
  const [form, setForm] = useState(blankBill);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState({ type: '', message: '' });

  const say = (type, message) => setNote({ type, message });
  const errMsg = (err, fallback) => err.response?.data?.message || fallback;

  const load = useCallback(async () => {
    try {
      const [s, b] = await Promise.all([getReminderSettings(), getBills()]);
      setSettings(s);
      setBills(b);
    } catch (err) {
      say('error', errMsg(err, 'Could not load reminders.'));
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const set = (key, value) => setSettings((s) => ({ ...s, [key]: value }));

  // asks the browser for permission the first time in-app notifications are switched on
  const togglePush = async (on) => {
    set('pushEnabled', on);
    if (on && typeof Notification !== 'undefined' && Notification.permission === 'default') {
      try {
        await Notification.requestPermission();
      } catch (e) {
        /* user can still use the bell */
      }
    }
  };

  const saveSettings = async () => {
    setBusy(true);
    try {
      const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || settings.timezone;
      const saved = await updateReminderSettings({
        emailEnabled: settings.emailEnabled,
        pushEnabled: settings.pushEnabled,
        dailyLogReminder: settings.dailyLogReminder,
        dailyLogTime: settings.dailyLogTime,
        billReminders: settings.billReminders,
        billNotifyDaysBefore: Number(settings.billNotifyDaysBefore),
        timezone,
      });
      setSettings(saved);
      say('success', 'Reminder settings saved.');
    } catch (err) {
      say('error', errMsg(err, 'Could not save settings.'));
    } finally {
      setBusy(false);
    }
  };

  const sendTest = async () => {
    setBusy(true);
    try {
      const res = await sendTestReminder();
      const mail = res.emailStatus === 'sent' ? ' E-mail sent.' : res.emailStatus === 'failed' ? ' E-mail could not be sent (check the SMTP settings).' : '';
      say(res.emailStatus === 'failed' ? 'error' : 'success', `Test reminder created.${mail}`);
    } catch (err) {
      say('error', errMsg(err, 'Could not send test.'));
    } finally {
      setBusy(false);
    }
  };

  const addBill = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await createBill({
        title: form.title,
        dueDate: form.dueDate,
        repeat: form.repeat,
        ...(form.amount !== '' ? { amount: Number(form.amount) } : {}),
      });
      setForm(blankBill);
      say('success', 'Bill reminder added.');
      setBills(await getBills());
    } catch (err) {
      say('error', errMsg(err, 'Could not add the bill.'));
    } finally {
      setBusy(false);
    }
  };

  const runBillAction = async (action, success) => {
    try {
      await action();
      say('success', success);
      setBills(await getBills());
    } catch (err) {
      say('error', errMsg(err, 'Something went wrong.'));
    }
  };

  if (!settings) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        {note.type === 'error' ? <p className="text-sm text-rose-500">{note.message}</p> : <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />}
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
          <BellRing className="w-6 h-6 text-emerald-500" />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Reminders</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">Automatic e-mail and in-app reminders for daily logging and bills.</p>
        </div>
      </div>

      {note.message && (
        <div
          role="status"
          className={`p-3 rounded-xl flex items-center gap-2.5 text-xs font-medium border ${
            note.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60'
              : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border-rose-200 dark:border-rose-800/60'
          }`}
        >
          {note.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {note.message}
        </div>
      )}

      {/* settings */}
      <div className={cardCls}>
        <h2 className="text-base font-bold text-slate-900 dark:text-white">Notification settings</h2>

        <Row icon={Smartphone} title="In-app & browser notifications" hint="Bell icon in the top bar, plus a browser pop-up while the app is open.">
          <Toggle checked={settings.pushEnabled} onChange={togglePush} label="In-app notifications" />
        </Row>

        <Row icon={Mail} title="E-mail reminders" hint={`Sent to ${user?.email || 'your e-mail'}.`}>
          <Toggle checked={settings.emailEnabled} onChange={(v) => set('emailEnabled', v)} label="E-mail reminders" />
        </Row>

        <Row icon={PencilLine} title="Daily logging reminder" hint="A nudge to record today's income and expenses.">
          <div className="flex items-center gap-3">
            <input
              type="time"
              aria-label="Daily reminder time"
              value={settings.dailyLogTime}
              onChange={(e) => set('dailyLogTime', e.target.value)}
              disabled={!settings.dailyLogReminder}
              className={`${inputCls} w-28 disabled:opacity-40`}
            />
            <Toggle checked={settings.dailyLogReminder} onChange={(v) => set('dailyLogReminder', v)} label="Daily logging reminder" />
          </div>
        </Row>

        <Row icon={CalendarClock} title="Bill due reminders" hint="Notify this many days before a bill is due (and again on the due day).">
          <div className="flex items-center gap-3">
            <input
              type="number"
              min="0"
              max="30"
              aria-label="Days before due"
              value={settings.billNotifyDaysBefore}
              onChange={(e) => set('billNotifyDaysBefore', e.target.value)}
              disabled={!settings.billReminders}
              className={`${inputCls} w-20 disabled:opacity-40`}
            />
            <Toggle checked={settings.billReminders} onChange={(v) => set('billReminders', v)} label="Bill due reminders" />
          </div>
        </Row>

        <div className="flex flex-wrap justify-end gap-3 pt-2">
          <button type="button" onClick={sendTest} disabled={busy} className={ghostBtn}>
            <Send className="w-4 h-4" />
            Send test reminder
          </button>
          <button type="button" onClick={saveSettings} disabled={busy} className={primaryBtn}>
            Save settings
          </button>
        </div>
      </div>

      {/* bills */}
      <div className={cardCls}>
        <h2 className="text-base font-bold text-slate-900 dark:text-white">Bill reminders</h2>

        <form onSubmit={addBill} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5 items-end">
          <div className="lg:col-span-2">
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="bill-title">Bill</label>
            <input id="bill-title" required placeholder="e.g. House rent" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputCls} />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="bill-amount">Amount</label>
            <input id="bill-amount" type="number" min="0" placeholder="optional" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className={inputCls} />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="bill-date">Due date</label>
            <input id="bill-date" required type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} className={inputCls} />
          </div>
          <div>
            <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider mb-1.5" htmlFor="bill-repeat">Repeat</label>
            <select id="bill-repeat" value={form.repeat} onChange={(e) => setForm({ ...form, repeat: e.target.value })} className={inputCls}>
              <option value="none">One time</option>
              <option value="monthly">Every month</option>
            </select>
          </div>
          <div className="sm:col-span-2 lg:col-span-5 flex justify-end">
            <button type="submit" disabled={busy} className={primaryBtn}>
              <Plus className="w-4 h-4" />
              Add bill
            </button>
          </div>
        </form>

        {bills.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">No bills yet. Add one above and you will be reminded before it is due.</p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {bills.map((b) => {
              const due = dueLabel(b.daysLeft);
              return (
                <li key={b._id} className={`py-3.5 flex flex-col sm:flex-row sm:items-center gap-3 ${b.isActive ? '' : 'opacity-50'}`}>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-slate-900 dark:text-white truncate">
                      {b.title}
                      {b.amount > 0 && <span className="ml-2 font-medium text-slate-500">· {b.amount}</span>}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {b.dueDate} · {b.repeat === 'monthly' ? 'every month' : 'one time'}
                      {!b.isActive && ' · paused'}
                    </p>
                  </div>
                  {b.isActive && <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border ${due.cls}`}>{due.text}</span>}
                  <div className="flex items-center gap-1.5">
                    {b.isActive && (
                      <button onClick={() => runBillAction(() => markBillPaid(b._id), `"${b.title}" marked as paid.`)} title="Mark as paid" aria-label={`Mark ${b.title} as paid`} className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/30">
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      onClick={() => runBillAction(() => updateBill(b._id, { isActive: !b.isActive }), b.isActive ? 'Reminder paused.' : 'Reminder resumed.')}
                      title={b.isActive ? 'Pause' : 'Resume'}
                      aria-label={`${b.isActive ? 'Pause' : 'Resume'} ${b.title}`}
                      className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      {b.isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => window.confirm(`Delete "${b.title}"?`) && runBillAction(() => deleteBill(b._id), 'Bill deleted.')}
                      title="Delete"
                      aria-label={`Delete ${b.title}`}
                      className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
