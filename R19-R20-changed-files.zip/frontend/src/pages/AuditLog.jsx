import React, { useState, useEffect, useCallback } from 'react';
import { History, Search, ChevronLeft, ChevronRight, Loader2, AlertCircle, FilterX, Plus, Pencil, Trash2, LogIn } from 'lucide-react';
import { getAuditLogs } from '../api/auditApi';

const ACTIONS = ['CREATE', 'UPDATE', 'DELETE', 'LOGIN'];
const ENTITIES = ['Account', 'Transaction', 'Category', 'Budget', 'Goal', 'Debt', 'SplitBill', 'Reminder', 'Profile', 'Security', 'Auth'];
const PAGE_SIZE = 15;

const ACTION_STYLE = {
  CREATE: { cls: 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800/60', Icon: Plus },
  UPDATE: { cls: 'bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-400 border-sky-200 dark:border-sky-800/60', Icon: Pencil },
  DELETE: { cls: 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 border-rose-200 dark:border-rose-800/60', Icon: Trash2 },
  LOGIN: { cls: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700', Icon: LogIn },
};

const inputCls =
  'w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500/40';

const emptyFilters = { search: '', action: '', entityType: '', from: '', to: '' };

// R20: read-only activity history
export default function AuditLog() {
  const [filters, setFilters] = useState(emptyFilters);
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState({ logs: [], total: 0, pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // wait until the user stops typing before searching
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(filters.search), 400);
    return () => clearTimeout(t);
  }, [filters.search]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const result = await getAuditLogs({
        search: debouncedSearch,
        action: filters.action,
        entityType: filters.entityType,
        from: filters.from,
        to: filters.to,
        page,
        limit: PAGE_SIZE,
      });
      setData(result);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load the activity history.');
    } finally {
      setLoading(false);
    }
  }, [debouncedSearch, filters.action, filters.entityType, filters.from, filters.to, page]);

  useEffect(() => {
    load();
  }, [load]);

  const change = (key) => (e) => {
    setFilters((f) => ({ ...f, [key]: e.target.value }));
    if (key !== 'search') setPage(1);
  };

  // typing a new search goes back to page 1 too
  useEffect(() => {
    setPage(1);
  }, [debouncedSearch]);

  const hasFilters = Object.values(filters).some(Boolean);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
          <History className="w-6 h-6 text-emerald-500" />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white">Activity History</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Everything you created, changed or deleted. This log is read-only.
          </p>
        </div>
      </div>

      {/* filters */}
      <div className="bg-white dark:bg-[#121826] p-4 rounded-3xl border border-slate-200/70 dark:border-slate-800/80 shadow-sm">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <div className="relative lg:col-span-2">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              aria-label="Search activity"
              placeholder="Search description..."
              value={filters.search}
              onChange={change('search')}
              className={`${inputCls} pl-9`}
            />
          </div>
          <select aria-label="Filter by action" value={filters.action} onChange={change('action')} className={inputCls}>
            <option value="">All actions</option>
            {ACTIONS.map((a) => (
              <option key={a} value={a}>{a}</option>
            ))}
          </select>
          <select aria-label="Filter by type" value={filters.entityType} onChange={change('entityType')} className={inputCls}>
            <option value="">All types</option>
            {ENTITIES.map((e) => (
              <option key={e} value={e}>{e}</option>
            ))}
          </select>
          <input aria-label="From date" type="date" value={filters.from} onChange={change('from')} className={inputCls} />
          <input aria-label="To date" type="date" value={filters.to} onChange={change('to')} className={inputCls} />
        </div>
        {hasFilters && (
          <button
            onClick={() => {
              setFilters(emptyFilters);
              setPage(1);
            }}
            className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline"
          >
            <FilterX className="w-3.5 h-3.5" />
            Clear filters
          </button>
        )}
      </div>

      {error && (
        <div className="p-3 rounded-xl flex items-center gap-2.5 text-xs font-medium bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800/60">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}

      {/* list */}
      <div className="bg-white dark:bg-[#121826] rounded-3xl border border-slate-200/70 dark:border-slate-800/80 shadow-sm overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 text-emerald-500 animate-spin" />
          </div>
        ) : data.logs.length === 0 ? (
          <p className="py-16 text-center text-sm text-slate-500 dark:text-slate-400">
            {hasFilters ? 'No activity matches these filters.' : 'No activity yet. Create an account and it will appear here.'}
          </p>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {data.logs.map((log) => {
              const { cls, Icon } = ACTION_STYLE[log.action] || ACTION_STYLE.LOGIN;
              const when = new Date(log.timestamp);
              return (
                <li key={log._id} className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 px-5 py-3.5">
                  <span className={`inline-flex items-center gap-1.5 w-24 justify-center px-2.5 py-1 rounded-lg text-[11px] font-bold border ${cls}`}>
                    <Icon className="w-3 h-3" />
                    {log.action}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">{log.description}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {log.entityType}
                      {log.changedFields?.length > 0 && ` · changed: ${log.changedFields.join(', ')}`}
                    </p>
                  </div>
                  <time dateTime={log.timestamp} className="text-xs text-slate-500 dark:text-slate-400 sm:text-right whitespace-nowrap">
                    {when.toLocaleDateString()} {when.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </time>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* pagination */}
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>{data.total} {data.total === 1 ? 'entry' : 'entries'}</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(p - 1, 1))}
            disabled={page <= 1 || loading}
            aria-label="Previous page"
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span>Page {data.page || page} of {data.pages}</span>
          <button
            onClick={() => setPage((p) => Math.min(p + 1, data.pages))}
            disabled={page >= data.pages || loading}
            aria-label="Next page"
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
