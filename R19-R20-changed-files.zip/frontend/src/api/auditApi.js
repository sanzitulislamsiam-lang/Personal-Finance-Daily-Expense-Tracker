import API from './axiosInstance';

// R20: activity history. params: { action, entityType, from, to, search, page, limit }
export const getAuditLogs = async (params = {}) => {
  // drop empty filters so they are not sent as "?action="
  const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== '' && v != null));
  const { data } = await API.get('/audit', { params: clean });
  return data; // { logs, page, limit, total, pages }
};
