import API from './axiosInstance';

// ---- R19: notification settings
export const getReminderSettings = async () => (await API.get('/reminders/settings')).data;
export const updateReminderSettings = async (payload) => (await API.put('/reminders/settings', payload)).data;
export const sendTestReminder = async () => (await API.post('/reminders/test')).data;

// ---- R19: bill reminders
export const getBills = async () => (await API.get('/reminders')).data;
export const createBill = async (payload) => (await API.post('/reminders', payload)).data;
export const updateBill = async (id, payload) => (await API.put(`/reminders/${id}`, payload)).data;
export const deleteBill = async (id) => (await API.delete(`/reminders/${id}`)).data;
export const markBillPaid = async (id) => (await API.post(`/reminders/${id}/paid`)).data;

// ---- R19: in-app notifications (the bell)
export const getNotifications = async (limit = 20) =>
  (await API.get('/notifications', { params: { limit } })).data; // { notifications, unreadCount }
export const markNotificationRead = async (id) => (await API.put(`/notifications/${id}/read`)).data;
export const markAllNotificationsRead = async () => (await API.put('/notifications/read-all')).data;
