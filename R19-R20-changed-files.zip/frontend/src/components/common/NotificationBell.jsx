import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Bell, CheckCheck, CalendarClock, PencilLine, FlaskConical } from 'lucide-react';
import { getNotifications, markNotificationRead, markAllNotificationsRead } from '../../api/reminderApi';

const POLL_MS = 60 * 1000; // look for new reminders every minute

const iconFor = (type) => {
  if (type === 'bill_due') return <CalendarClock className="w-4 h-4 text-amber-500" />;
  if (type === 'daily_log') return <PencilLine className="w-4 h-4 text-emerald-500" />;
  return <FlaskConical className="w-4 h-4 text-sky-500" />;
};

const timeAgo = (iso) => {
  const mins = Math.floor((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr ago`;
  return new Date(iso).toLocaleDateString();
};

// R19: bell in the navbar. Shows unread reminders and (if the user allowed it)
// pops a browser notification when a NEW reminder arrives.
export default function NotificationBell() {
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);
  const seen = useRef(null); // ids we already know (so only NEW ones trigger a pop-up)
  const box = useRef(null);

  const load = useCallback(async () => {
    try {
      const data = await getNotifications(15);
      setItems(data.notifications);
      setUnread(data.unreadCount);

      if (seen.current === null) {
        // first load: remember everything, do not pop up old reminders
        seen.current = new Set(data.notifications.map((n) => n._id));
        return;
      }
      data.notifications
        .filter((n) => !n.isRead && !seen.current.has(n._id))
        .forEach((n) => {
          seen.current.add(n._id);
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(n.title, { body: n.message });
          }
        });
    } catch (e) {
      /* bell is optional - ignore network errors, try again next minute */
    }
  }, []);

  useEffect(() => {
    load();
    const timer = setInterval(load, POLL_MS);
    return () => clearInterval(timer);
  }, [load]);

  // close when clicking outside
  useEffect(() => {
    const onClick = (e) => {
      if (box.current && !box.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const readOne = async (n) => {
    if (n.isRead) return;
    setItems((prev) => prev.map((x) => (x._id === n._id ? { ...x, isRead: true } : x)));
    setUnread((c) => Math.max(c - 1, 0));
    try {
      await markNotificationRead(n._id);
    } catch (e) {
      load();
    }
  };

  const readAll = async () => {
    setItems((prev) => prev.map((x) => ({ ...x, isRead: true })));
    setUnread(0);
    try {
      await markAllNotificationsRead();
    } catch (e) {
      load();
    }
  };

  return (
    <div className="relative" ref={box}>
      <button
        onClick={() => {
          setOpen((o) => !o);
          if (!open) load();
        }}
        className="relative p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all border border-slate-200 dark:border-slate-700"
        title="Reminders"
        aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}
      >
        <Bell className="w-4 h-4" />
        {unread > 0 && (
          <span
            data-testid="unread-badge"
            className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center"
          >
            {unread > 9 ? '9+' : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 mt-2 w-80 max-w-[90vw] bg-white dark:bg-[#121826] border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100 dark:border-slate-800">
            <span className="text-sm font-bold text-slate-900 dark:text-white">Reminders</span>
            {unread > 0 && (
              <button onClick={readAll} className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline">
                <CheckCheck className="w-3.5 h-3.5" />
                Mark all read
              </button>
            )}
          </div>

          <div className="max-h-80 overflow-y-auto">
            {items.length === 0 ? (
              <p className="px-4 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
                No reminders yet.
              </p>
            ) : (
              items.map((n) => (
                <button
                  key={n._id}
                  onClick={() => readOne(n)}
                  className={`w-full text-left flex gap-3 px-4 py-3 border-b border-slate-50 dark:border-slate-800/60 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors ${
                    n.isRead ? 'opacity-60' : 'bg-emerald-50/40 dark:bg-emerald-950/10'
                  }`}
                >
                  <span className="mt-0.5">{iconFor(n.type)}</span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-xs font-bold text-slate-900 dark:text-white">{n.title}</span>
                    <span className="block text-xs text-slate-600 dark:text-slate-300 mt-0.5">{n.message}</span>
                    <span className="block text-[10px] text-slate-400 mt-1">{timeAgo(n.createdAt)}</span>
                  </span>
                  {!n.isRead && <span className="mt-1.5 w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
