import React from 'react';
import { render, screen, waitFor, within, act } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi, describe, test, expect, beforeEach, afterEach } from 'vitest';

vi.mock('../api/auditApi', () => ({ getAuditLogs: vi.fn() }));
vi.mock('../api/reminderApi', () => ({
  getReminderSettings: vi.fn(),
  updateReminderSettings: vi.fn(),
  sendTestReminder: vi.fn(),
  getBills: vi.fn(),
  createBill: vi.fn(),
  updateBill: vi.fn(),
  deleteBill: vi.fn(),
  markBillPaid: vi.fn(),
  getNotifications: vi.fn(),
  markNotificationRead: vi.fn(),
  markAllNotificationsRead: vi.fn(),
}));

import * as reminderApi from '../api/reminderApi';
import { getAuditLogs } from '../api/auditApi';
import { AuthProvider } from '../context/AuthContext';
import NotificationBell from '../components/common/NotificationBell';
import AuditLog from '../pages/AuditLog';
import Reminders from '../pages/Reminders';

const storeUser = () =>
  localStorage.setItem('userInfo', JSON.stringify({ _id: 'u1', name: 'T', email: 'me@test.com', token: 'jwt', privacySettings: {} }));

const note = (over = {}) => ({
  _id: 'n1',
  type: 'bill_due',
  title: 'Bill due today: Rent',
  message: '"Rent" is due today.',
  isRead: false,
  createdAt: new Date().toISOString(),
  ...over,
});

beforeEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
});

// ---------------------------------------------------------------------------
describe('R19 notification bell', () => {
  test('shows the unread count, lists reminders and marks one as read', async () => {
    reminderApi.getNotifications.mockResolvedValue({
      notifications: [note(), note({ _id: 'n2', title: 'Time to log your expenses', type: 'daily_log' })],
      unreadCount: 2,
    });
    reminderApi.markNotificationRead.mockResolvedValue({});
    render(<NotificationBell />);

    expect(await screen.findByTestId('unread-badge')).toHaveTextContent('2');
    await userEvent.click(screen.getByRole('button', { name: /notifications, 2 unread/i }));
    expect(screen.getByText('Bill due today: Rent')).toBeInTheDocument();

    await userEvent.click(screen.getByText('Bill due today: Rent'));
    expect(reminderApi.markNotificationRead).toHaveBeenCalledWith('n1');
    expect(screen.getByTestId('unread-badge')).toHaveTextContent('1');
  });

  test('"Mark all read" clears the badge', async () => {
    reminderApi.getNotifications.mockResolvedValue({ notifications: [note(), note({ _id: 'n2' })], unreadCount: 2 });
    reminderApi.markAllNotificationsRead.mockResolvedValue({});
    render(<NotificationBell />);
    await screen.findByTestId('unread-badge');
    await userEvent.click(screen.getByRole('button', { name: /notifications/i }));
    await userEvent.click(screen.getByText('Mark all read'));
    expect(reminderApi.markAllNotificationsRead).toHaveBeenCalled();
    await waitFor(() => expect(screen.queryByTestId('unread-badge')).not.toBeInTheDocument());
  });

  test('empty state', async () => {
    reminderApi.getNotifications.mockResolvedValue({ notifications: [], unreadCount: 0 });
    render(<NotificationBell />);
    await userEvent.click(await screen.findByRole('button', { name: /notifications/i }));
    expect(screen.getByText('No reminders yet.')).toBeInTheDocument();
    expect(screen.queryByTestId('unread-badge')).not.toBeInTheDocument();
  });

  test('a NEW reminder triggers a browser notification, old ones do not', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const popup = vi.fn();
    vi.stubGlobal('Notification', Object.assign(popup, { permission: 'granted' }));

    reminderApi.getNotifications.mockResolvedValueOnce({ notifications: [note()], unreadCount: 1 });
    render(<NotificationBell />);
    await screen.findByTestId('unread-badge');
    expect(popup).not.toHaveBeenCalled(); // first load = existing reminders, no pop-up

    reminderApi.getNotifications.mockResolvedValue({
      notifications: [note({ _id: 'n9', title: 'Brand new reminder' }), note()],
      unreadCount: 2,
    });
    await act(async () => {
      vi.advanceTimersByTime(60 * 1000);
    });
    await waitFor(() => expect(popup).toHaveBeenCalledTimes(1));
    expect(popup).toHaveBeenCalledWith('Brand new reminder', expect.any(Object));

    vi.useRealTimers();
    vi.unstubAllGlobals();
  });
});

// ---------------------------------------------------------------------------
describe('R20 activity history page', () => {
  const log = (over = {}) => ({
    _id: 'l1',
    action: 'CREATE',
    entityType: 'Account',
    description: 'Created account "Brac Bank"',
    changedFields: [],
    timestamp: new Date().toISOString(),
    ...over,
  });

  test('renders the entries with action, description and changed fields', async () => {
    getAuditLogs.mockResolvedValue({
      logs: [log(), log({ _id: 'l2', action: 'UPDATE', description: 'Updated account "Brac Bank"', changedFields: ['name', 'balance'] })],
      page: 1,
      pages: 1,
      total: 2,
    });
    render(<AuditLog />);
    expect(await screen.findByText('Created account "Brac Bank"')).toBeInTheDocument();
    expect(screen.getByText('Updated account "Brac Bank"')).toBeInTheDocument();
    expect(screen.getByText(/changed: name, balance/)).toBeInTheDocument();
    expect(screen.getByText('2 entries')).toBeInTheDocument();
  });

  test('filters are sent to the API and can be cleared', async () => {
    getAuditLogs.mockResolvedValue({ logs: [log()], page: 1, pages: 1, total: 1 });
    render(<AuditLog />);
    await screen.findByText('Created account "Brac Bank"');

    await userEvent.selectOptions(screen.getByLabelText('Filter by action'), 'DELETE');
    await waitFor(() =>
      expect(getAuditLogs).toHaveBeenLastCalledWith(expect.objectContaining({ action: 'DELETE', page: 1 }))
    );
    await userEvent.selectOptions(screen.getByLabelText('Filter by type'), 'Account');
    await waitFor(() =>
      expect(getAuditLogs).toHaveBeenLastCalledWith(expect.objectContaining({ action: 'DELETE', entityType: 'Account' }))
    );

    await userEvent.click(screen.getByText('Clear filters'));
    await waitFor(() =>
      expect(getAuditLogs).toHaveBeenLastCalledWith(expect.objectContaining({ action: '', entityType: '' }))
    );
  });

  test('search waits for typing to stop, then asks the API', async () => {
    getAuditLogs.mockResolvedValue({ logs: [], page: 1, pages: 1, total: 0 });
    render(<AuditLog />);
    await screen.findByText(/No activity yet/);
    await userEvent.type(screen.getByLabelText('Search activity'), 'bkash');
    await waitFor(() => expect(getAuditLogs).toHaveBeenLastCalledWith(expect.objectContaining({ search: 'bkash' })));
    expect(getAuditLogs.mock.calls.filter(([p]) => p.search === 'b' || p.search === 'bk')).toHaveLength(0);
  });

  test('pagination buttons change the page', async () => {
    getAuditLogs.mockResolvedValue({ logs: [log()], page: 1, pages: 3, total: 40 });
    render(<AuditLog />);
    await screen.findByText('Created account "Brac Bank"');
    expect(screen.getByLabelText('Previous page')).toBeDisabled();

    await userEvent.click(screen.getByLabelText('Next page'));
    await waitFor(() => expect(getAuditLogs).toHaveBeenLastCalledWith(expect.objectContaining({ page: 2 })));
  });

  test('empty-with-filters message and error message', async () => {
    getAuditLogs.mockResolvedValueOnce({ logs: [log()], page: 1, pages: 1, total: 1 });
    render(<AuditLog />);
    await screen.findByText('Created account "Brac Bank"');

    getAuditLogs.mockResolvedValue({ logs: [], page: 1, pages: 1, total: 0 });
    await userEvent.selectOptions(screen.getByLabelText('Filter by action'), 'LOGIN');
    expect(await screen.findByText('No activity matches these filters.')).toBeInTheDocument();

    getAuditLogs.mockRejectedValue({ response: { data: { message: 'action must be one of: ...' } } });
    await userEvent.selectOptions(screen.getByLabelText('Filter by action'), 'UPDATE');
    expect(await screen.findByText(/action must be one of/)).toBeInTheDocument();
  });
});

// ---------------------------------------------------------------------------
describe('R19 reminders page', () => {
  const settings = {
    emailEnabled: false,
    pushEnabled: true,
    dailyLogReminder: false,
    dailyLogTime: '20:00',
    billReminders: true,
    billNotifyDaysBefore: 2,
    timezone: 'Asia/Dhaka',
  };
  const bills = [
    { _id: 'b1', title: 'House rent', amount: 15000, dueDate: '2026-11-10', repeat: 'monthly', isActive: true, daysLeft: 3 },
    { _id: 'b2', title: 'Old bill', amount: 0, dueDate: '2026-11-01', repeat: 'none', isActive: true, daysLeft: -6 },
  ];

  const renderPage = () =>
    render(
      <AuthProvider>
        <Reminders />
      </AuthProvider>
    );

  beforeEach(() => {
    storeUser();
    reminderApi.getReminderSettings.mockResolvedValue(settings);
    reminderApi.getBills.mockResolvedValue(bills);
  });

  test('shows the saved settings and the bills with due labels', async () => {
    renderPage();
    expect(await screen.findByText('House rent')).toBeInTheDocument();
    expect(screen.getByText('Due in 3 day(s)')).toBeInTheDocument();
    expect(screen.getByText('Overdue by 6 day(s)')).toBeInTheDocument();
    expect(screen.getByRole('switch', { name: 'In-app notifications' })).toHaveAttribute('aria-checked', 'true');
    expect(screen.getByRole('switch', { name: 'E-mail reminders' })).toHaveAttribute('aria-checked', 'false');
    expect(screen.getByText(/me@test\.com/)).toBeInTheDocument();
  });

  test('saving sends every setting plus the browser time zone', async () => {
    reminderApi.updateReminderSettings.mockResolvedValue({ ...settings, emailEnabled: true, dailyLogReminder: true, dailyLogTime: '07:30' });
    renderPage();
    await screen.findByText('House rent');

    await userEvent.click(screen.getByRole('switch', { name: 'E-mail reminders' }));
    await userEvent.click(screen.getByRole('switch', { name: 'Daily logging reminder' }));
    const time = screen.getByLabelText('Daily reminder time');
    await userEvent.clear(time);
    await userEvent.type(time, '07:30');
    await userEvent.click(screen.getByText('Save settings'));

    await waitFor(() => expect(reminderApi.updateReminderSettings).toHaveBeenCalledTimes(1));
    const payload = reminderApi.updateReminderSettings.mock.calls[0][0];
    expect(payload).toMatchObject({
      emailEnabled: true,
      pushEnabled: true,
      dailyLogReminder: true,
      dailyLogTime: '07:30',
      billReminders: true,
      billNotifyDaysBefore: 2,
    });
    expect(typeof payload.timezone).toBe('string');
    expect(await screen.findByText('Reminder settings saved.')).toBeInTheDocument();
  });

  test('"Send test reminder" reports success and failure', async () => {
    reminderApi.sendTestReminder.mockResolvedValueOnce({ inApp: true, emailStatus: 'sent' });
    renderPage();
    await screen.findByText('House rent');
    await userEvent.click(screen.getByText('Send test reminder'));
    expect(await screen.findByText(/Test reminder created\. E-mail sent\./)).toBeInTheDocument();

    reminderApi.sendTestReminder.mockRejectedValueOnce({ response: { data: { message: 'Turn on e-mail or in-app notifications first, then send a test.' } } });
    await userEvent.click(screen.getByText('Send test reminder'));
    expect(await screen.findByText(/Turn on e-mail or in-app/)).toBeInTheDocument();
  });

  test('adding a bill sends the form values and refreshes the list', async () => {
    reminderApi.createBill.mockResolvedValue({});
    renderPage();
    await screen.findByText('House rent');

    await userEvent.type(screen.getByLabelText('Bill'), 'Netflix');
    await userEvent.type(screen.getByLabelText('Amount'), '800');
    await userEvent.type(screen.getByLabelText('Due date'), '2026-12-05');
    await userEvent.selectOptions(screen.getByLabelText('Repeat'), 'monthly');
    await userEvent.click(screen.getByText('Add bill'));

    await waitFor(() =>
      expect(reminderApi.createBill).toHaveBeenCalledWith({ title: 'Netflix', amount: 800, dueDate: '2026-12-05', repeat: 'monthly' })
    );
    await waitFor(() => expect(reminderApi.getBills).toHaveBeenCalledTimes(2));
  });

  test('mark paid, pause and delete (with confirmation)', async () => {
    reminderApi.markBillPaid.mockResolvedValue({});
    reminderApi.updateBill.mockResolvedValue({});
    reminderApi.deleteBill.mockResolvedValue({});
    renderPage();
    await screen.findByText('House rent');

    await userEvent.click(screen.getByLabelText('Mark House rent as paid'));
    expect(reminderApi.markBillPaid).toHaveBeenCalledWith('b1');

    await userEvent.click(screen.getByLabelText('Pause House rent'));
    expect(reminderApi.updateBill).toHaveBeenCalledWith('b1', { isActive: false });

    const confirm = vi.spyOn(window, 'confirm');
    confirm.mockReturnValueOnce(false);
    await userEvent.click(screen.getByLabelText('Delete House rent'));
    expect(reminderApi.deleteBill).not.toHaveBeenCalled(); // cancelled

    confirm.mockReturnValueOnce(true);
    await userEvent.click(screen.getByLabelText('Delete House rent'));
    expect(reminderApi.deleteBill).toHaveBeenCalledWith('b1');
    confirm.mockRestore();
  });

  test('server validation message is shown when adding a bill fails', async () => {
    reminderApi.createBill.mockRejectedValue({ response: { data: { message: 'dueDate must be a real date like 2026-12-01' } } });
    renderPage();
    await screen.findByText('House rent');
    await userEvent.type(screen.getByLabelText('Bill'), 'X');
    await userEvent.type(screen.getByLabelText('Due date'), '2026-12-05');
    await userEvent.click(screen.getByText('Add bill'));
    expect(await screen.findByText(/dueDate must be a real date/)).toBeInTheDocument();
  });
});
