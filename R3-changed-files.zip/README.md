# Personal-Finance-Daily-Expense-Tracker

## R3 - Data Privacy & Security

* **Balance masking** - eye button in the navbar / Accounts page hides every balance. *Profile -> Mask Balances on Startup* saves the default.
* **PIN lock** - *Profile -> PIN Lock*: create / change / remove a 4-digit PIN (bcrypt hash) and choose which sections it locks. A locked section shows a PIN screen and stays open for 10 minutes. 5 wrong PINs = 5 minute lock-out.
* Locks are enforced **on the server** too (`middleware/pinMiddleware.js`): API calls to a locked section need the `x-pin-token` header returned by `POST /api/users/verify-pin`.

| Method | Endpoint | Purpose |
|---|---|---|
| PUT | `/api/users/privacy` | `{ maskBalances?, lockedSections?, pin? }` |
| POST | `/api/users/pin` | `{ pin, currentPin? }` create / change PIN |
| DELETE | `/api/users/pin` | `{ pin }` remove PIN |
| POST | `/api/users/verify-pin` | `{ pin }` -> `unlockToken` |

Tests: `cd backend && npm test` (needs local MongoDB) and `cd frontend && npm test`.
To lock another page: wrap it with `<PinLock section="budgets">` in `App.jsx` and add `router.use(requirePinUnlock('budgets'))` in its routes file.
